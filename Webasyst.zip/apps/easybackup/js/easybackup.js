/*global $*/
"use strict";
var backup = {
    id: '',
    type: '',
    dialog: '',
    self: this,
    processId: null,
    process: false,
    urlps: '?action=process',
    urlst: '',
    urlrn: '?action=run',
    csrf: $('[name=_csrf]').attr("value"),
    ready: false,
    loc: null,
    reload: function() {
        var $state = $.cookie('b-state') ? $.cookie('b-state') : 'b-new';
        $("#" + $state).click();
    },
    checkprocess: function() {
        if (self.process) {
            alert('Please, wait the process to finish.');
            return true;
        }
        else return false;
    },
    setInfo: function(data, action) {
        if (backup.ready) return;
        var info = "";
        $.each(data.stage, function(key, value) {
            info = info + '</br>' + value;
        });
        if (action == "dump") {
            $('#info').html(info);
        }
        else {
            $('#info-restore').html(info);
        }
        if (data.ready) backup.ready = true;
    },
    checkError: function (data, error) {
        if ((!data.processId || data.error) && backup.process) {
            if (data.rescue == 'restored') error = $_('Restore error. Try once more and contact the developer. Temporary copies were succesfully restored.');
            $('#error-caption').text(error);
            $('#error-text').text(data.error);
            $('#wa-recovery').show();
            return true;
        }
        return false;
    },
    
    dumpproc: function(response) {
        backup.setInfo(response);
        if (backup.checkError(response, $_('Init process error. Try once more and contact the developer:'))) return;
        var timerId = setInterval(function() {
            var posting = $.post(backup.urlrn, {
                _csrf: backup.csrf,
                processId: response.processId
            });
            posting.fail(function(data){
                console.log("Data:"+JSON.stringify(data));
            })
            .done(function(data) {
                if (backup.checkError(data, $_('Backup process error. Backup is not created, try once more and contact the developer: '))) {
                    clearInterval(timerId);
                    return;
                }
                backup.setInfo(data, "dump");
                if (data.ready) {
                    $('#loading').hide();
                    $('#yes').show();
                    backup.process = false;
                    clearInterval(timerId);
                }
            });
        }, 4000);
    },
    restoreproc: function(response) {
        if (backup.checkError(response, $_('Init process error. Try once more and contact the developer:'))) {
            clearInterval(timerId);
            return;
        }
        var timerId = setInterval(function() {
            var posting = $.post(backup.urlrn, {
                _csrf: backup.csrf,
                processId: response.processId
            });
            posting.done(function(data) {
                if (backup.checkError(data, $_('Restore error. Try once more and contact the developer. Temporary copies were succesfully restored.'))) {
                    clearInterval(timerId);
                    return;
                }
                backup.setInfo(data, "restore");
                if (data.ready) {
                    clearInterval(timerId);
                    $('#loading-restore').hide();
                    $('#yes-restore').show();
                    backup.process = false;
                    $.storage.del('easybackup/counters');
                }
            });
        }, 4000);
    }
    
    
};

 var restore_selected = function() {
    backup.dialog.trigger('close');
    backup.type = '';
    if ($("#res-wac").prop("checked")) backup.type += 'wac';
    if ($("#res-db").prop("checked")) backup.type += 'db';
    if ($("#res-img").prop("checked")) backup.type += 'img';
    if ($("#res-tmb").prop("checked")) backup.type += 'tmb';
    if ($("#res-edt").prop("checked")) backup.type += 'edt';
    if ($("#res-thm").prop("checked")) backup.type += 'thm';
    if (backup.type == '') {
        alert($_('Select at least one param.'));
        return;
    }
    backup.ready = false;
    backup.checkprocess();
    backup.process = true;
    $('.progress-restore').show();
    $.post(backup.urlrn, {
        _csrf: backup.csrf,
        action: 'restore',
        backup: backup.id,
        type: backup.type
    }).success(function(data) {
        backup.setInfo(data, "restore");
        backup.restoreproc(data);
    });
};

window.onbeforeunload = function (e) {
    if (!backup.process) return;
    e = e || window.event;
    // For IE and Firefox prior to version 4
    
    if (e) {
        e.returnValue = $_('Please, wait the process to finish.');
    }
    // For Safari
    return $_('Please, wait the process to finish.');
};

$(function() {
    backup.reload();
    $.wa.errorHandler = function(){return}; //Не ломать отображение в случае ошибки.
    
    $("#b-new").click(function(){
        if (backup.process) return true;
        $.cookie('b-state', 'b-new');
        $('#s-sidebar').find('.selected').removeClass('selected');
        $(this).parent().attr("class", "selected");
        $("#content").load("?action=backup");
    });

    $("#b-restore").click(function(){
        if (backup.process) return true;
        $.cookie('b-state', 'b-restore');
        $('#s-sidebar').find('.selected').removeClass('selected');
        $(this).parent().attr("class", "selected");
        $("#content").load("?action=restore");
    });
    
    $("#b-cron").click(function(){
        if (backup.process) return true;
        $.cookie('b-state', 'b-cron');
        $('#s-sidebar').find('.selected').removeClass('selected');
        $(this).parent().attr("class", "selected");
        $("#content").load("?action=cron");
    });
    
    $("#content").on("click","#savesettings", function() {
        var type = '';
        if ($("#set-wac").prop("checked")) type += 'wac';
        if ($("#set-db").prop("checked")) type += 'db';
        if ($("#set-img").prop("checked")) type += 'img';
        if ($("#set-tmb").prop("checked")) type += 'tmb';
        if ($("#set-edt").prop("checked")) type += 'edt';
        if ($("#set-thm").prop("checked")) type += 'thm';
        var rotate = $('#rotate-num').val();
        var token = $('#token').val();
        var ftp = $("#b-set-ftp").prop("checked");
        var yad = $("#b-set-yad").prop("checked");
        
        $.post(backup.urlps, {
            _csrf: backup.csrf,
            backup: type,
            rotate_num: rotate,
            ftp: ftp,
            yad: yad,
            token: token,
            action: 'savesettings'
        }).done(function() {
            $("#savesettings").after(' <i class="icon16 yes saved"></i>');
            setTimeout(function () {
                $(".saved").fadeOut();
            }, 2000);
        });
    });

    $("#content").on("click","#dump", function() {
        backup.checkprocess();
        backup.ready = false;
        var text = $('#text').val();
        var type = '';
        if ($("#wac").prop("checked")) type += 'wac';
        if ($("#db").prop("checked")) type += 'db';
        if ($("#img").prop("checked")) type += 'img';
        if ($("#tmb").prop("checked")) type += 'tmb';
        if ($("#edt").prop("checked")) type += 'edt';
        if ($("#thm").prop("checked")) type += 'thm';
        if (type == '') {
            alert($_('Select at least one param.'));
            backup.process = false;
            return;
        }
        backup.process = true;
        $('.progress').show();
        $(this).hide();
        $.post(backup.urlrn, {
            _csrf: backup.csrf,
            action: 'dump',
            type: type,
            text: text
        }).success(function(data) {
            backup.setInfo(data, "dump");
            backup.dumpproc(data);
        });
    });

    $(".disabled, #disabled").click(function() {
        alert($_('Remove temporary copies.'));
    });

    $("#content").on("click",".delete", function() {
        if (confirm($_("Confirm remove."))) {
            var backupId = $(this).data('backup');
            $.post(backup.urlps, {
                _csrf: backup.csrf,
                backup: backupId,
                action: 'delete'
            }).done(function() {
                backup.reload();
            });
        }
    });
    
    $("#content").on("click",".compress", function() {
            var backupId = $(this).data('backup');
            $(this).find('i').removeClass("folders").addClass("loading");
            $.post(backup.urlps, {
                _csrf: backup.csrf,
                backup: backupId,
                action: 'compress'
            }).done(function() {
                backup.reload();
            });
    });
    
    $("#content").on("click",".download", function(e) {
            var backupId = $(this).data('backup');
            e.preventDefault(); 
            window.location.href = '?action=process&backup=' + backupId;
    });

    $("#content").on("click",".bckp", function() {
        $(".field.bckpdiv").hide();
        if ($(this).attr('id') == "deletebckp") $(".bckpdiv-remove").show();
        if ($(this).attr('id') == "restorebckp") $(".bckpdiv-restore").show();
        var posting = $.post(backup.urlps, {
            _csrf: backup.csrf,
            action: $(this).attr('id')
        });
        posting.done(function(response) {
            if (response == 'restored') alert($_("Temporary copies are restored."));
            backup.reload();
        });
        posting.fail(function() {
            alert($_("Error on restore action."))
        });
    });

   
    $("#content").on("click",".restore", function() {
        $('.value.no-shift').hide();
        if ($('.elements').length > 2) $('.dialog').remove();
        backup.id = $(this).attr('id');
        if (backup.id.indexOf("wac") >= 0) $('.res-wac').show();
        if (backup.id.indexOf("db") >= 0) $('.res-db').show();
        if (backup.id.indexOf("img") >= 0) $('.res-img').show();
        if (backup.id.indexOf("tmb") >= 0) $('.res-tmb').show();
        if (backup.id.indexOf("edt") >= 0) $('.res-edt').show();
        if (backup.id.indexOf("thm") >= 0) $('.res-thm').show();
        $('.elements').show();
        backup.dialog = $('.elements').waDialog({
            'width': '450px',
            'height': '250px',
            'title':$_('Items to restore'),
            'buttons':'<center><a href="javascript:restore_selected()" class="button green" id="restore-but">'+$_('Restore')+'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" class="button red cancel" id="restore-cancel">'+$_('Cancel')+'</a></center>',
        });

    });
    backup.reload();
});

