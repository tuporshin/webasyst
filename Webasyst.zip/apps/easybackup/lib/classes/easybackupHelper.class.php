<?php

class easybackupHelper
{

    public static function restoreBckp()
    {
        try {
            $data_model = new waModel();
            $tables = $data_model->query('SHOW TABLES')->fetchAll();
            foreach ($tables as $k => $table) {
                if ((substr($table[key($tables[0])], 0, 5) == 'bckp_') && ($data_model->query("SHOW TABLES LIKE '" . substr($table[key($tables[0])], 5) . "'")->fetchArray())) {
                    $data_model->exec('DROP TABLE ' . substr($table[key($tables[0])], 5));
                    $data_model->exec('RENAME TABLE ' . $table[key($tables[0])] . ' TO ' . substr($table[key($tables[0])], 5));
                }
            }
            if (file_exists(wa()->getDataPath('bckp_products', true, 'shop'))) {
                waFiles::delete(wa()->getDataPath('products', true, 'shop'));
                rename(wa()->getDataPath('bckp_products', true, 'shop'), wa()->getDataPath('products', true, 'shop'));
            }
            if (file_exists(wa()->getDataPath('bckp_products', false, 'shop'))) {
                waFiles::delete(wa()->getDataPath('products', false, 'shop'));
                rename(wa()->getDataPath('bckp_products', false, 'shop'), wa()->getDataPath('products', false, 'shop'));
            }
            if (file_exists(wa()->getConfig()->getRootPath() . '/bckp_wa-config')) {
                waFiles::delete(wa()->getConfigPath());
                rename(wa()->getConfig()->getRootPath() . '/bckp_wa-config', wa()->getConfigPath());
            }
        } catch (Exception $ex) {
            self::error($ex->getMessage() . "\n" . $ex->getTraceAsString());
            exit;
        } catch (waException $ex) {
            self::error($ex->getMessage() . "\n" . $ex->getTraceAsString());
            exit;
        }
        return 'restored';
    }

    public static function checkBckp()
    {
        $data_model = new waModel();
        $tables = $data_model->query('SHOW TABLES')->fetchAll();
        foreach ($tables as $k => $table) {
            if (substr($table[key($tables[0])], 0, 4) == 'bckp') {
                return true;
            }
        }
        if (file_exists(wa()->getDataPath('bckp_products', true, 'shop', false))) {
            return true;
        }
        if (file_exists(wa()->getDataPath('bckp_edt', true, 'shop', false))) {
            return true;
        }
        if (file_exists(wa()->getDataPath('bckp_products', false, 'shop', false))) {
            return true;
        }
        if (file_exists(wa()->getConfig()->getRootPath() . '/bckp_wa-config')) {
            return true;
        }
        return false;
    }

    public static function getLastPosition($file)
    {
        $fp = fopen($file, 'r');
        fseek($fp, 0, SEEK_END);
        return ftell($fp);
    }

    public static function getImgSize()
    {
        $imgsize = array();
        $imgsize['img'] = waFiles::formatSize(self::folderSize(wa()->getDataPath('products', false, 'shop')));
        $imgsize['tmb'] = waFiles::formatSize(self::folderSize(wa()->getDataPath('products', true, 'shop')));
        $imgsize['edt'] = waFiles::formatSize(self::folderSize(wa()->getDataPath('img', true, 'shop')));
        return $imgsize;
    }

    public static function folderSize($dir)
    {
        $size = 0;
        if (!is_array(glob(rtrim($dir, '/') . '/*'))) {
            return 0;
        }
        foreach (glob(rtrim($dir, '/') . '/*', GLOB_NOSORT) as $each) {
            $size += is_file($each) ? filesize($each) : self::folderSize($each);
        }
        return $size;
    }

    public static function getDbSize()
    {
        $data_model = new waModel();
        $res = $data_model->query('SHOW TABLE STATUS')->fetchAll();
        $size = 0;
        $count = 0;
        foreach ($res as $table) {
            $count += 1;
            $size += $table['Data_length'] + $table['Index_length'];
        }
        
        return waFiles::formatSize($size) . ', ' . $count . " " . _w('tables');
    }
    
    public static function getUserRights()
    {
        if (wa()->getUser()->isAdmin('easybackup')) {
            return array(
                'backup' => true,
                'restore' => true,
                'delete' => true,
                'cron' => true,
                'download' => true
                );
        }
        else {
            return wa()->getUser()->getRights('easybackup');
        }
    }
    
    // deprecated
    public static function zipData($source, $destination) {
        @set_time_limit(0);
        if (extension_loaded('zip')) {
            if (file_exists($source)) {
                $zip = new ZipArchive();
                if ($zip->open($destination, ZIPARCHIVE::CREATE)) {
                    $source = realpath($source);
                    if (is_dir($source)) {
                        $iterator = new RecursiveDirectoryIterator($source);
                        $iterator->setFlags(RecursiveDirectoryIterator::SKIP_DOTS);
                        $files = new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::SELF_FIRST);
                        foreach ($files as $file) {
                            $file = realpath($file);
                            if (is_dir($file)) {
                                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
                            } else if (is_file($file)) {
                                $zip->addFile($file, str_replace($source . '/', '', $file));
                            }
                        }
                    } else if (is_file($source)) {
                        $zip->addFromString(basename($source), file_get_contents($source));
                    }
                }
                return $zip->close();
            }
        }
        return false;
    }
    
    
    public static function tarData($source, $destination) {
        @set_time_limit(0);
        if (class_exists('waAutoload')) {
            waAutoload::getInstance()->add('Archive_Tar', '/wa-installer/lib/vendors/PEAR/Tar.php');
            waAutoload::getInstance()->add('PEAR', '/wa-installer/lib/vendors/PEAR/PEAR.php');
        }
        $tar = new Archive_Tar($destination, true);
        return $tar->addModify($source, "", dirname($source));
    }
    
    
    
    public static function shell_access() {
		if (!is_callable('exec')) {
			return false;
		}
		$disabled_functions = @ini_get('disable_functions');
		return stripos($disabled_functions, 'shell_exec') === false;
	}
	
	public static function command_available($command) {
		if (preg_match('~win~i', PHP_OS)) {
			$output = array();
			exec('where /Q ' . $command, $output, $return_val);
			if (intval($return_val) === 1) {
				return false;
			} else {
				return true;
			}
		} else {
			$last_line = exec('which ' . $command);
			$last_line = trim($last_line);
			if (empty($last_line)) {
				return false;
			} else {
				return true;
			}
		}
		
	}

    public static function error($message)
    {
        waLog::log($message, 'easybackup/backup_error.log');
    }
}
