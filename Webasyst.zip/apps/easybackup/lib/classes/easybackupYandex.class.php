<?php

// Подключается только при php >= 5.3

use Yandex\Disk\DiskClient;  


class easybackupYandex
{
    public static function upload($fileName, $newName, $token) {
        require_once 'phar://' . wa()->getAppPath('lib/vendors', 'easybackup') . '/yandex-php-library_0.4.0.phar/vendor/autoload.php';
        $diskClient = new DiskClient($token);
        $diskClient->setServiceScheme(DiskClient::HTTPS_SCHEME);
        try {
            $diskClient->uploadFile(
                    '/',
                    array(
                        'path' => $fileName,
                        'size' => filesize($fileName),
                        'name' => $newName
                    )
                );
                waLog::log('YD upload completed', 'easybackup/backup_cron.log');
        } catch (Exception $e) {
            if ($e->getCode() == 401) {
                waLog::log('Cannot upload to YandexDisk, check your token', 'easybackup/backup_cron.log');
            } else {
                waLog::log($e->getMessage(), 'easybackup/backup_cron.log');
            }
            
        }
    }
}
