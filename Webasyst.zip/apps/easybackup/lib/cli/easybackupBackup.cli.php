<?php

class easybackupBackupCli extends waCliController

{
    public function execute()
    {
        $asm = new waAppSettingsModel();
        $s = $asm->get('easybackup');
        $data_path = wa()->getDataPath('backup', false, 'easybackup');
        $backup_dest = $data_path . "/current/";
        
        $this->cronlog("Cron backup initialized to: " . $backup_dest);
        
        
        if (strstr($s['cronstring'], 'wac')) {
            waFiles::copy(wa()->getConfigPath() , $backup_dest . 'wa-config');
            $this->cronlog("Config saved");
        }
        if (strstr($s['cronstring'], 'img')) {
            waFiles::copy(wa()->getDataPath('products', false, 'shop') , $backup_dest . 'products');
            $this->cronlog("Image originals saved");
        }
        if (strstr($s['cronstring'], 'tmb')) {
            waFiles::copy(wa()->getDataPath('products', true, 'shop') , $backup_dest . 'thumbs');
            $this->cronlog("Image thumbs saved");
        }
        if (strstr($s['cronstring'], 'edt')) {
            waFiles::copy(wa()->getDataPath('img', true, 'shop') , $backup_dest . 'edt');
            $this->cronlog("Image editor saved");
        }

        if (strstr($s['cronstring'], 'thm')) {
            $apps = wa()->getApps();
            foreach ($apps as $id => $app) {
                if (isset($app['themes'])) {
                    if (file_exists(wa()->getAppPath('themes', $id))) {
                        waFiles::copy(wa()->getAppPath('themes', $id) , $backup_dest . 'themes/' . $id . '/protected/');
                        $this->cronlog("Themes originals saved: $id");
                    }
                    if (file_exists(wa()->getDataPath('themes', true, $id))) {
                        waFiles::copy(wa()->getDataPath('themes', true, $id) , $backup_dest . 'themes/' . $id . '/public/');
                        $this->cronlog("Themes edited saved: $id");
                    }
                }
            }
        }

        if (strstr($s['cronstring'], 'db')) {
            $this->cronlog("Database dump started");
            try {
                $db = waSystem::getInstance()->getConfig()->getDatabase();
                $data_model = new waModel();
                $tables_list = $data_model->query('SHOW TABLES')->fetchAll();
                $tblist = array();
                $tables = array();
                foreach($tables_list as $k => $table) {
                    $tables[$k]['name'] = $table[key($tables_list[0]) ];
                    $tblist[] = $tables[$k]['name'];
                    $fields = $data_model->query("SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '" . $db['default']['database'] . "' AND table_name = '" . $tables[$k]['name'] . "'")->fetchAll();
                    foreach($fields as $field) {
                        $tables[$k]['fields'][] = $field['column_name'];
                    }
                    $tables[$k]['field_count'] = count($tables[$k]['fields']);
                    $tables[$k]['row_count'] = $data_model->query('SELECT COUNT(*) FROM ' . $tables[$k]['name'])->fetchField();
                }
                if (!waFiles::write($backup_dest . 'db/tblist', serialize($tblist))) {
                    throw new Exception('Не удалось записать файл для копии базы данных, проверьте права');
                }
                if (!waFiles::create($backup_dest . 'db/database.sql')) {
                    throw new Exception('Не удалось создать файл для копии базы данных, проверьте права');
                }
                $content = 'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";' . "\nSET FOREIGN_KEY_CHECKS=0;\n\n";
                file_put_contents($backup_dest . 'db/database.sql', $content, FILE_APPEND);
                foreach($tables as $tb) {
                    $showcreate = $data_model->query('SHOW CREATE TABLE ' . $tb['name'])->fetchArray();
                    $content.= 'DROP TABLE IF EXISTS `' . $tb['name'] . "`;\n\n" . $showcreate[1] . ";\n\n";
                    file_put_contents($backup_dest . 'db/database.sql', $content, FILE_APPEND);
                    for ($offset = 0; $offset < $tb['row_count']; $offset+= 400) {
                        $result = $data_model->query('SELECT * FROM `' . $tb['name'] . '` LIMIT ' . $offset . ', 400')->fetchAll();
                        $rows_num = count($result);
                        $content = '';
                        $counter = 0;
                        foreach($result as $row) {
                            if ($counter % 50 == 0 || $counter == 0) {
                                $content.= "\nINSERT IGNORE INTO " . $tb['name'] . ' VALUES';
                            }
                            $content.= "\n(";
                            for ($j = 0; $j < $tb['field_count']; ++$j) {
                                if (isset($row[$tb['fields'][$j]])) {
                                    $content.= '"' . str_replace("\n", '\\n', addslashes($row[$tb['fields'][$j]])) . '"';
                                }
                                else {
                                    $content.= 'NULL';
                                }
                                if ($j < ($tb['field_count'] - 1)) {
                                    $content.= ',';
                                }
                            }
                            $content.= ')';
                            if ((($counter + 1) % 50 == 0 && $counter != 0) || $counter + 1 == $rows_num) {
                                $content.= ';';
                            }
                            else {
                                $content.= ',';
                            }
                            $counter+= 1;
                        }
                        $content.= "\n\n";
                        $handle = file_put_contents($backup_dest . 'db/database.sql', $content, FILE_APPEND);
                    }
                }
                $this->cronlog("Database dump saved");
            }
            catch(Exception $ex) {
                $this->cronlog($ex->getMessage() . "\n" . $ex->getTraceAsString());
                exit;
            }
            catch(waException $ex) {
                $this->cronlog($ex->getMessage() . "\n" . $ex->getTraceAsString());
                exit;
            }
        }
        
        $size = waFiles::formatSize(easybackupHelper::folderSize($backup_dest));
        file_put_contents($backup_dest . 'info', 
                json_encode(array(
                    'size' => $size, 
                    'info' => 'cron', 
                    'name' => time())));
                    
        if (file_exists($backup_dest)) {
            $backup_folder = date('Y-m-d_H-i-s') . $s['cronstring'];
            $backup_path = wa()->getDataPath('backup/', false, 'easybackup') . $backup_folder;
            rename($backup_dest, $backup_path);
            $this->cronlog("Database folder renamed to: " . $backup_path);
        }
        
        //zip if upload
        if (($s['ftp'] == "true") || ($s['yad'] == "true")) {
            $this->cronlog('Backup compress started');
            $backup_archive = $backup_path . "/" . $backup_folder . ".tar.gz";
            $result = easybackupHelper::tarData($backup_path, $backup_archive);
            if (!$result) {
                $this->cronlog('Cannot compress backup');
                return;
            }
            $this->cronlog('Backup compressed');
        }
        
        //FTP Upload
        if (($s['ftp'] == "true")) {
            $this->cronlog('FTP upload started');
            $server = $asm->get('easybackup', 'server');
            $port = $asm->get('easybackup', 'port');
            $login = $asm->get('easybackup', 'login');
            $password = $asm->get('easybackup', 'password');
            $path = $asm->get('easybackup', 'path');
            $connect = ftp_connect($server, $port);
            if (!$connect) {
                $this->cronlog('Connection to FTP server failed');
                return;
            }
            if (@ftp_login($connect, $login, $password)) {
                if ($path == "" || @ftp_chdir($connect, $path)) {
                    ftp_pasv($connect, true);
                    $upload = @ftp_put($connect, $backup_folder . ".tar.gz", $backup_archive, FTP_BINARY);
                    if (!$upload) {
                        $this->cronlog('Cannot upload archive');
                    } else {
                        $this->cronlog('Backup uploaded succesfully');
                    }
                } 
                else {
                    $this->cronlog('Cannot switch to FTP path');
                    return;
                }        
            } else {
                $this->cronlog('Wrong FTP connection credentials');
                return;
            }
            ftp_close($connect);
            $this->cronlog('FTP upload completed');
        }
        
        //Yandex.Disk upload
        if (($s['yad'] == "true") && $s['token'] && version_compare(phpversion(), "5.3.0", ">=")) {
            $this->cronlog('YD upload started with token: ' . $s['token']);
            $fileName = $backup_path . "/" . $backup_folder . ".tar.gz";
            $newName = $backup_folder . ".tar.gz";
            
            easybackupYandex::upload($fileName, $newName, $s['token']);
        }
        
        //rotate
        $rotate_num = $asm->get('easybackup', 'rotate_num');
        $backup_list = waFiles::listdir($data_path);
        $backup_list_cron = array();
        foreach ($backup_list as $backup) {
            $data = json_decode(file_get_contents($data_path . '/' . $backup . '/info'), true);
            if ($data['info'] == "cron") {
                $backup_list_cron[] = $backup;
            }
        }
        arsort($backup_list_cron);
        $unneeded = array_slice($backup_list_cron, $rotate_num);
        foreach ($unneeded as $backup) {
                waFiles::delete($data_path . '/' . $backup);
                $this->cronlog($backup . " removed by rotation with number " . $rotate_num);
        }
    }
    
    private function cronlog($message)
    {
        waLog::log($message, 'easybackup/backup_cron.log');
    }
}
