<?php
return array (
  'name' => /*_w*/('Easy backup'),
  'icon'        => array(
      16 => 'img/16.png',
      24 => 'img/24.png',
      48 => 'img/48.png',
      96 => 'img/96.png',
  ),
  'version' => '1.3',
  'vendor' => '1027956',
  'rights' => 1,
);
