<?php

class easybackupRightConfig extends waRightConfig
{
    public function init()
    {
        $this->addItem('restore', _w('Can restore from backups'));
        $this->addItem('backup', _w('Can create backups'));
        $this->addItem('download', _w('Can download backups'));
        $this->addItem('delete', _w('Can delete backups'));
        $this->addItem('cron', _w('Can edit cron settings'));

        /**
         * @event rights.config
         * @param waRightConfig $this Rights setup object
         * @return void
         */
        wa()->event('rights.config', $this);
    }
}