<?php

class easybackupBackendController extends waViewController
{
    public function execute()
    {
        $this->setLayout(new easybackupBackendLayout());
    }
}