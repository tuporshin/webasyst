<?php
class easybackupBackendBackupAction extends waViewAction
{
    public function execute()
    {
        if (!$this->getRights('backup')||!$this->getUser()->isAdmin('easybackup')) throw new waRightsException(_ws('Access denied'));
        $asm = new waAppSettingsModel();
        $themed_apps = array();
        $apps = wa()->getApps();
            foreach ($apps as $id => $app) {
                if (array_key_exists('themes', $app)) {
                    $themed_apps[] = $app['name'];
                }
            }
        $themes = implode(', ', $themed_apps);
        
        $this->view->assign('size', json_decode($asm->get('easybackup', 'size'), true));
        $this->view->assign('themes', $themes);
        $this->view->assign('bckp', easybackupHelper::checkBckp());
    }
}
