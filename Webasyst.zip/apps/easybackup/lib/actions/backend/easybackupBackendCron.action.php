<?php
class easybackupBackendCronAction extends waViewAction
{
    public function execute()
    {
        if (!$this->getRights('cron')||!$this->getUser()->isAdmin('easybackup')) throw new waRightsException(_ws('Access denied'));
        $asm = new waAppSettingsModel();
        $s = $asm->get('easybackup');
        if (!isset($s['rotate_num']) || $s['rotate_num'] == "") $s['rotate_num'] = 2;
        $this->view->assign('s', $s);
        $this->view->assign('root', wa()->getConfig()->getRootPath());
        $this->view->assign('v', version_compare(phpversion(), "5.3.0", ">="));
    }
}
