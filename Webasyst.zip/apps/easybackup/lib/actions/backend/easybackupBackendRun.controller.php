<?php

class easybackupBackendRunController extends waLongActionController
{
    public function execute()
    {
        try {
            parent::execute();
        } catch (waException $ex) {
            if ($ex->getCode() == '302') {
                echo json_encode(
                    array(
                        'warning' => $ex->getMessage(),
                    )
                );
            } else {
                echo json_encode(
                    array(
                        'error' => $ex->getMessage(),
                    )
                );
            }
        }
    }

    protected function init()
    {
        try {
            if (!$this->getRights('backup') && waRequest::post('action') == 'dump') throw new waRightsException(_ws('Access denied'));
            if (!$this->getRights('restore') && waRequest::post('action') == 'restore') throw new waRightsException(_ws('Access denied'));
            $data_path = wa()->getDataPath('backup', false, 'easybackup');
            $this->data['action'] = waRequest::post('action');
            $this->data['type'] = waRequest::post('type');
            $this->data['backup'] = waRequest::post('backup');
            $this->data['text'] = waRequest::post('text');
            $this->data['backup_dest'] = $data_path. '/current/';
            $this->data['backup_loc'] = $data_path . '/' . $this->data['backup'] . '/';
            waFiles::delete($this->data['backup_dest']);
            $this->data['info'][0] = _w('Process started');
            switch ($this->data['action']) {
                case 'dump':
                    $this->initDump();
                    break;

                case 'restore':
                    $this->initRestore();
                    break;
            }
            $this->data['error'] = '';
            $this->data['done'] = false;
            $this->data['memory'] = memory_get_peak_usage();
            $this->data['memory_avg'] = memory_get_usage();
            $this->data['timestamp'] = time();
        } catch (Exception $ex) {
            $this->error($ex->getMessage() . "\n" . $ex->getTraceAsString(), $this->data['action']);
            exit;
        } catch (waException $ex) {
            $this->error($ex->getMessage() . "\n" . $ex->getTraceAsString(), $this->data['action']);
            exit;
        }
    }

    protected function initDump()
    {
        waFiles::create($this->data['backup_dest'], true);

        if (strstr($this->data['type'], 'wac')) {
            $this->data['wac'] = false;
        }

        if (strstr($this->data['type'], 'db') && !$this->mysqldump()) {
            $db = waSystem::getInstance()->getConfig()->getDatabase();
            $data_model = new waModel();
            $this->data['db']['rows'] = $data_model->query(
                "SELECT SUM(TABLE_ROWS) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '" . $db['default']['database'] . "'"
            )->fetchField();
            $tables = $data_model->query('SHOW TABLES')->fetchAll();
            $tblist = array();
            foreach ($tables as $k => $table) {
                $this->data['tables'][$k]['name'] = $table[key($tables[0])];
                $tblist[] = $this->data['tables'][$k]['name'];
                $fields = $data_model->query(
                    "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '" . $db['default']['database'] . "' AND table_name = '" . $this->data['tables'][$k]['name'] . "'"
                )->fetchAll();
                foreach ($fields as $field) {
                    $this->data['tables'][$k]['fields'][] = $field['column_name'];
                }
                $this->data['tables'][$k]['field_count'] = count($this->data['tables'][$k]['fields']);
                $this->data['tables'][$k]['row_count'] = $data_model->query('SELECT COUNT(*) FROM ' . $this->data['tables'][$k]['name'])->fetchField();
                $this->data['tables'][$k]['limit'] = 400;
                $this->data['tables'][$k]['steps'] = ceil($this->data['tables'][$k]['row_count'] / $this->data['tables'][$k]['limit']);
                $this->data['tables'][$k]['step'] = 0;
            }
            $this->data['db']['count'] = count($this->data['tables']);
            if (!waFiles::write($this->data['backup_dest'] . 'db/tblist', serialize($tblist))) {
                /** @noinspection ThrowRawExceptionInspection */
                throw new Exception(_w('Database backup file write error, check access rights.'));
            }
            $this->data['info'][1] = _w('Tables in database:') . ' ' . $this->data['db']['count'];
            $this->data['db']['current'] = 0;
            $this->data['recordsdone'] = 0;
            if (!waFiles::create($this->data['backup_dest'] . 'db/database.sql')) {
                throw new Exception(_w('Database backup file create error, check access rights.'));
            }
        }

        if (strstr($this->data['type'], 'img')) {
            $this->data['img']['path'] = wa()->getDataPath('products', false, 'shop');
            $this->data['img']['files'] = waFiles::listdir($this->data['img']['path'], true);
            $this->data['img']['backup_dest_img'] = $this->data['backup_dest'] . 'products/';
            $this->data['img']['count'] = count($this->data['img']['files']);
            if (!waFiles::create($this->data['img']['backup_dest_img'], true)) {
                throw new Exception(
                    _w('Images backup folder create error, check access rights.')
                );
            }
            $this->data['img']['current'] = 0;
        }

        if (strstr($this->data['type'], 'tmb')) {
            $this->data['tmb']['path'] = wa()->getDataPath('products', true, 'shop');
            $this->data['tmb']['files'] = waFiles::listdir($this->data['tmb']['path'], true);
            $this->data['tmb']['backup_dest_img'] = $this->data['backup_dest'] . 'thumbs/';
            $this->data['tmb']['count'] = count($this->data['tmb']['files']);
            if (!waFiles::create($this->data['tmb']['backup_dest_img'], true)) {
                throw new Exception(
                    _w('Images backup folder create error, check access rights.')
                );
            }
            $this->data['tmb']['current'] = 0;
        }
        if (strstr($this->data['type'], 'edt')) {
            $this->data['edt']['path'] = wa()->getDataPath('img', true, 'shop');
            $this->data['edt']['files'] = waFiles::listdir($this->data['edt']['path'], true);
            $this->data['edt']['backup_dest_img'] = $this->data['backup_dest'] . 'edt/';
            $this->data['edt']['count'] = count($this->data['edt']['files']);
            if (!waFiles::create($this->data['edt']['backup_dest_img'], true)) {
                throw new Exception(
                    _w('Images backup folder create error, check access rights.')
                );
            }
            $this->data['edt']['current'] = 0;
        }
        
        if (strstr($this->data['type'], 'thm')) {
            $this->data['thm'] = false;
        }
    }

    protected function initRestore()
    {
        if (strstr($this->data['type'], 'wac') && file_exists($this->data['backup_loc'] . 'wa-config')) {
            if (!waFiles::move(wa()->getConfigPath(), wa()->getConfig()->getRootPath() . '/bckp_wa-config')) {
                throw new Exception(
                    _w('Temporary configuration copy create error, check access rights for root folder and available diskspace.')
                );
            }
            waFiles::copy($this->data['backup_loc'] . 'wa-config', wa()->getConfigPath());
            $this->data['wac'] = true;
            $this->data['info'][0] = _w('Configuration has been restored.');
        }
        if (strstr($this->data['type'], 'db') && file_exists($this->data['backup_loc'] . 'db/database.sql')) {
            $data_model = new waModel();
            $tblistfile = file_get_contents($this->data['backup_loc'] . 'db/tblist');
            if (!$tblistfile) {
                throw new Exception(
                    _w('Unable to read file') . $this->data['backup_loc'] . 'db/tblist' . _w(', check access rights.')
                );
            }
            $tblist = unserialize($tblistfile);
            foreach ($tblist as $tb) {
                if ($data_model->query("SHOW TABLES LIKE '" . $tb . "'")->fetchField()) {
                    $data_model->exec('CREATE TABLE bckp_' . $tb . ' LIKE ' . $tb);
                    $data_model->exec('INSERT bckp_' . $tb . ' SELECT * FROM ' . $tb);
                }
            }
            $this->data['info'][1] = _w('Temporary tables copy has been created.');
            if (!$this->mysqlrestore()) {
                $this->data['db']['file'] = $this->data['backup_loc'] . 'db/database.sql';
                $this->data['db']['current'] = 0;
                $this->data['db']['count'] = easybackupHelper::getLastPosition($this->data['db']['file']);
            } else {
                $this->data['info'][1] .= '</br>' . _w('Database has been restored.');
            }
        }
        if (strstr($this->data['type'], 'img') && file_exists($this->data['backup_loc'] . 'products')) {
            $this->data['img']['path'] = $this->data['backup_loc'] . 'products';
            $this->data['img']['files'] = waFiles::listdir($this->data['backup_loc'] . 'products', true);
            $this->data['img']['count'] = count($this->data['img']['files']);
            $this->data['img']['restore_path'] = wa()->getDataPath('products', false, 'shop');
            if (!waFiles::move($this->data['img']['restore_path'], wa()->getDataPath(null, false, 'shop') . '/bckp_products')) {
                throw new Exception(
                    _w('Product originals copy create error, check access rights and available diskspace.')
                );
            }
            $this->data['img']['current'] = 0;
            $this->data['info'][2] = _w('Product originals temporary copy has been created.');
        }
        if (strstr($this->data['type'], 'tmb') && file_exists($this->data['backup_loc'] . 'thumbs')) {
            $this->data['tmb']['path'] = $this->data['backup_loc'] . 'thumbs';
            $this->data['tmb']['files'] = waFiles::listdir($this->data['backup_loc'] . 'thumbs', true);
            $this->data['tmb']['count'] = count($this->data['tmb']['files']);
            $this->data['tmb']['restore_path'] = wa()->getDataPath('products', true, 'shop');
            if (!waFiles::move($this->data['tmb']['restore_path'], wa()->getDataPath(null, true, 'shop') . '/bckp_products')) {
                throw new Exception(
                    _w('Product originals copy create error, check access rights and available diskspace.')
                );
            }
            $this->data['tmb']['current'] = 0;
            $this->data['info'][3] = _w('Product thumbs temporary copy has been created.');
        }
        if (strstr($this->data['type'], 'edt') && file_exists($this->data['backup_loc'] . 'edt')) {
            $this->data['edt']['path'] = $this->data['backup_loc'] . 'edt';
            $this->data['edt']['files'] = waFiles::listdir($this->data['backup_loc'] . 'edt', true);
            $this->data['edt']['count'] = count($this->data['edt']['files']);
            $this->data['edt']['restore_path'] = wa()->getDataPath('img', true, 'shop');
            if (!waFiles::move($this->data['edt']['restore_path'], wa()->getDataPath(null, true, 'shop') . '/bckp_edt')) {
                throw new Exception(
                    _w('WYSIWYG-editor images copy create error, check access rights and available diskspace.')
                );
            }
            $this->data['edt']['current'] = 0;
            $this->data['info'][4] = _w('WYSIWYG-editor temporary copy has been created.');
        }
        if (strstr($this->data['type'], 'thm') && file_exists($this->data['backup_loc'] . 'themes')) {
            $this->data['thm'] = false;
        }
    }

    protected function info($filename = null)
    {
        $interval = 0;
        if (!empty($this->data['timestamp'])) {
            $interval = time() - $this->data['timestamp'];
        }
        $response = array(
            'time' => sprintf('%d:%02d:%02d', floor($interval / 3600), floor($interval / 60) % 60, $interval % 60),
            'processId' => $this->processId,
            'ready' => $this->isDone(),
            'stage' => $this->data['info'],
            'error' => $this->data['error'],
            'memory' => sprintf('%0.2fMByte', $this->data['memory'] / 1048576),
            'memory_avg' => sprintf('%0.2fMByte', $this->data['memory_avg'] / 1048576),
        );
        $this->getResponse()->addHeader('Content-type', 'application/json');
        $this->getResponse()->sendHeaders();
        echo json_encode($response);
    }

    protected function infoReady($filename)
    {
        $interval = 0;
        if (!empty($this->data['timestamp'])) {
            $interval = time() - $this->data['timestamp'];
        }
        $response = array(
            'time' => sprintf('%d:%02d:%02d', floor($interval / 3600), floor($interval / 60) % 60, $interval % 60),
            'processId' => $this->processId,
            'ready' => $this->isDone(),
            'stage' => $this->data['info'],
            'error' => $this->data['error'],
            'memory' => sprintf('%0.2fMByte', $this->data['memory'] / 1048576),
            'memory_avg' => sprintf('%0.2fMByte', $this->data['memory_avg'] / 1048576),
        );
        $this->getResponse()->addHeader('Content-type', 'application/json');
        $this->getResponse()->sendHeaders();
        echo json_encode($response);
    }

    protected function isDone()
    {
        if ($this->data['error']) {
            return true;
        }
        if (isset($this->data['wac']) && !$this->data['wac']) {
            return false;
        }
        if (isset($this->data['db']['count']) && $this->data['db']['current'] < $this->data['db']['count']) {
            return false;
        }
        if (isset($this->data['img']['count']) && $this->data['img']['current'] < $this->data['img']['count']) {
            return false;
        }
        if (isset($this->data['tmb']['count']) && $this->data['tmb']['current'] < $this->data['tmb']['count']) {
            return false;
        }
        if (isset($this->data['edt']['count']) && $this->data['edt']['current'] < $this->data['edt']['count']) {
            return false;
        }
        if (isset($this->data['thm']) && !$this->data['thm']) {
            return false;
        }
        return true;
    }

    protected function step()
    {
        $method_name = 'step' . ucfirst($this->data['action']);
        $result = false;
        try {
            if (method_exists($this, $method_name)) {
                $result = $this->$method_name();
            } else {
                $this->error(sprintf('Unsupported action %s', $this->data['action']));
            }
        } catch (Exception $ex) {
            sleep(5);
            $this->data['error'] = $ex->getMessage() . "\n" . $ex->getTraceAsString();
            $this->error($this->data['action'] . ': ' . $ex->getMessage() . "\n" . $ex->getTraceAsString(), $this->data['action']);
        } catch (waException $ex) {
            sleep(5);
            $this->data['error'] = $ex->getMessage() . "\n" . $ex->getTraceAsString();
            $this->error($this->data['action'] . ': ' . $ex->getMessage() . "\n" . $ex->getTraceAsString(), $this->data['action']);
        }
        $this->data['memory'] = memory_get_peak_usage();
        $this->data['memory_avg'] = memory_get_usage();

        return $result && !$this->isDone();
    }

    protected function finish($filename)
    {
        if ($this->data['error']) {
            return false;
        }
        if (file_exists($this->data['backup_dest'])) {
            $size = waFiles::formatSize(easybackupHelper::folderSize($this->data['backup_dest']));
            $info = htmlspecialchars($this->data['text']);
            $handle = file_put_contents($this->data['backup_dest'] . 'info', 
                json_encode(array(
                    'size' => $size, 
                    'info' => $info, 
                    'name' => time())));
            if (!$handle) {
                throw new Exception(_w('Unable to write backup description file, check access rights.'));
            }
            rename(
                $this->data['backup_dest'],
                wa()->getDataPath('backup/', false, 'easybackup') . date('Y-m-d_H-i-s') . $this->data['type']
            );
        }
        return false;
    }

    protected function stepDump()
    {
        if (strstr($this->data['type'], 'wac')) {
            waFiles::copy(wa()->getConfigPath(), $this->data['backup_dest'] . 'wa-config');
            $this->data['wac'] = true;
            $this->data['info'][3] = _w('Configuration has been saved.');
        }
        if (strstr($this->data['type'], 'db') && $this->data['db']['current'] < $this->data['db']['count']) {
            $tb = $this->data['tables'][$this->data['db']['current']]['name'];
            $step = $this->data['tables'][$this->data['db']['current']]['step'];
            $limit = $this->data['tables'][$this->data['db']['current']]['limit'];
            $offset = $step * $limit;
            $data_model = new waModel();
            $result = $data_model->query('SELECT * FROM `' . $tb . '` LIMIT ' . $offset . ', ' . $limit)->fetchAll();
            $fields_amount = $this->data['tables'][$this->data['db']['current']]['field_count'];
            $rows_num = count($result);
            $content = '';
            if ($step == 0) {
                if ($this->data['db']['current'] == 0) {
                    $content .= 'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";' . "\nSET FOREIGN_KEY_CHECKS=0;\n\n";
                }
                $showcreate = $data_model->query('SHOW CREATE TABLE ' . $tb)->fetchArray();
                $content .= 'DROP TABLE IF EXISTS `' . $tb . "`;\n\n" . $showcreate[1] . ";\n\n";
            } else $content = '';
            $fields = $this->data['tables'][$this->data['db']['current']]['fields'];
            $counter = 0;
            foreach ($result as $row) {
                ++$this->data['recordsdone'];
                $this->data['info'][4] = _w('Entries processed:') . ' ' . ceil($this->data['recordsdone'] / $this->data['db']['rows'] * 100) . '% (' . $this->data['recordsdone'] . _w(' from ') . $this->data['db']['rows'] . ')';
                if ($counter % 50 == 0 || $counter == 0) {
                    $content .= "\nINSERT IGNORE INTO " . $tb . ' VALUES';
                }
                $content .= "\n(";
                for ($j = 0; $j < $fields_amount; ++$j) {
                    if (isset($row[$fields[$j]])) {
                        $content .= '"' . str_replace("\n", '\\n', addslashes($row[$fields[$j]])) . '"';
                    } else {
                        $content .= 'NULL';
                    }
                    if ($j < ($fields_amount - 1)) {
                        $content .= ',';
                    }
                }
                $content .= ')';
                if ((($counter + 1) % 50 == 0 && $counter != 0) || $counter + 1 == $rows_num) {
                    $content .= ';';
                } else {
                    $content .= ',';
                }
                ++$counter;
            }
            $content .= "\n\n";
            $handle = file_put_contents($this->data['backup_dest'] . 'db/database.sql', $content, FILE_APPEND);
            if (!$handle) {
                $this->data['error'] = _w('Unable to write data to a file copy of the database, check access rights and available diskspace.');
                throw new Exception($this->data['error']);
            }
            if ($step < $this->data['tables'][$this->data['db']['current']]['steps']) {
                $this->data['tables'][$this->data['db']['current']]['step'] += 1;
            } else {
                $this->data['db']['current'] += 1;
            }

            return true;
        }
        if (strstr($this->data['type'], 'img') && ($this->data['img']['current'] < $this->data['img']['count'])) {
            waFiles::copy(
                $this->data['img']['path'] . '/' . $this->data['img']['files'][$this->data['img']['current']],
                $this->data['img']['backup_dest_img'] . $this->data['img']['files'][$this->data['img']['current']]
            );
            $this->data['img']['current'] += 1;
            $this->data['info'][5] = _w('Product images copies:') . ' ' . ceil($this->data['img']['current'] / $this->data['img']['count'] * 100) . '% (' . $this->data['img']['current'] . _w(' from ') . $this->data['img']['count'] . ')';

            return true;
        }
        if (strstr($this->data['type'], 'tmb') && ($this->data['tmb']['current'] < $this->data['tmb']['count'])) {
            waFiles::copy(
                $this->data['tmb']['path'] . '/' . $this->data['tmb']['files'][$this->data['tmb']['current']],
                $this->data['tmb']['backup_dest_img'] . $this->data['tmb']['files'][$this->data['tmb']['current']]
            );
            $this->data['tmb']['current'] += 1;
            $this->data['info'][6] = _w('Product thumbs copied:') . ' ' . ceil($this->data['tmb']['current'] / $this->data['tmb']['count'] * 100) . '% (' . $this->data['tmb']['current'] . _w(' from ') . $this->data['tmb']['count'] . ')';

            return true;
        }
        
        if (strstr($this->data['type'], 'edt') && ($this->data['edt']['current'] < $this->data['edt']['count'])) {
            waFiles::copy(
                $this->data['edt']['path'] . '/' . $this->data['edt']['files'][$this->data['edt']['current']],
                $this->data['edt']['backup_dest_img'] . $this->data['edt']['files'][$this->data['edt']['current']]
            );
            $this->data['edt']['current'] += 1;
            $this->data['info'][7] = _w('WYSIWYG-editor images copied:') . ' ' . ceil($this->data['edt']['current'] / $this->data['edt']['count'] * 100) . '% (' . $this->data['edt']['current'] . _w(' from ') . $this->data['edt']['count'] . ')';

            return true;
        }
                
        if (strstr($this->data['type'], 'thm')) {
            $apps = wa()->getApps();
            foreach ($apps as $id => $app) {
                if (isset($app['themes'])) {
                    if (file_exists(wa()->getAppPath('themes', $id))) {
                        waFiles::copy(wa()->getAppPath('themes', $id) , $this->data['backup_dest'] . 'themes/' . $id . '/protected/');
                    }
                    if (file_exists(wa()->getDataPath('themes', true, $id))) {
                        waFiles::copy(wa()->getDataPath('themes', true, $id) , $this->data['backup_dest'] . 'themes/' . $id . '/public/');
                    }
                }
                    
            }
            $this->data['thm'] = true;
            $this->data['info'][8] = _w('App themes have been copied.');
        }

        return true;
    }

    protected function stepRestore()
    {
        if (strstr($this->data['type'], 'db') && $this->data['db']['current'] < $this->data['db']['count']) {
            $data_model = new waModel();
            $deadline = time() + 5;
            $fp = fopen($this->data['db']['file'], 'r');
            fseek($fp, $this->data['db']['current']);
            $query = '';
            while ($deadline > time() and ($line = fgets($fp, 102400))) {
                if (substr($line, 0, 2) == '--' or trim($line) == '') {
                    continue;
                }
                $query .= $line;
                if (substr(trim($query), -1) == ';') {
                    $data_model->exec($query);
                    $query = '';
                    $this->data['db']['current'] = ftell($fp);
                    $this->data['info'][5] = _w('Entries processed:') . ' ' . ceil(($this->data['db']['current'] + 3) / $this->data['db']['count'] * 100) . '% (' . ($this->data['db']['current'] + 3) . _w(' from ') . $this->data['db']['count'] . ')';
                }
            }
            if (feof($fp)) {
                $this->data['db']['current'] = $this->data['db']['count'];
            }

            return true;
        }
        if (strstr($this->data['type'], 'img') && ($this->data['img']['current'] < $this->data['img']['count'])) {
            waFiles::copy(
                $this->data['img']['path'] . '/' . $this->data['img']['files'][$this->data['img']['current']],
                $this->data['img']['restore_path'] . '/' . $this->data['img']['files'][$this->data['img']['current']]
            );
            $this->data['img']['current'] += 1;
            $this->data['info'][6] = _w('Product originals copied:') . ' ' . ceil($this->data['img']['current'] / $this->data['img']['count'] * 100) . '% (' . $this->data['img']['current'] . _w(' from ') . $this->data['img']['count'] . ')';
            return true;
        }

        if (strstr($this->data['type'], 'tmb') && ($this->data['tmb']['current'] < $this->data['tmb']['count'])) {
            waFiles::copy(
                $this->data['tmb']['path'] . '/' . $this->data['tmb']['files'][$this->data['tmb']['current']],
                $this->data['tmb']['restore_path'] . '/' . $this->data['tmb']['files'][$this->data['tmb']['current']]
            );
            $this->data['tmb']['current'] += 1;
            $this->data['info'][7] = _w('Product thumbs copied:') . ' ' . ceil($this->data['tmb']['current'] / $this->data['tmb']['count'] * 100) . '% (' . $this->data['tmb']['current'] . _w(' from ') . $this->data['tmb']['count'] . ')';
            return true;
        }
        
        if (strstr($this->data['type'], 'edt') && ($this->data['edt']['current'] < $this->data['edt']['count'])) {
            waFiles::copy(
                $this->data['edt']['path'] . '/' . $this->data['edt']['files'][$this->data['edt']['current']],
                $this->data['edt']['restore_path'] . '/' . $this->data['edt']['files'][$this->data['edt']['current']]
            );
            $this->data['edt']['current'] += 1;
            $this->data['info'][8] = _w('WYSIWYG-editor images copied:') . ' ' . ceil($this->data['edt']['current'] / $this->data['edt']['count'] * 100) . '% (' . $this->data['edt']['current'] . _w(' from ') . $this->data['edt']['count'] . ')';
            return true;
        }
        
        if (strstr($this->data['type'], 'thm')) {
            $app_list = waFiles::listdir($this->data['backup_loc'] . 'themes');
            foreach ($app_list as $app) {
                if (file_exists($this->data['backup_loc'] . 'themes/' . $app . '/public')) {
                    waFiles::delete(wa()->getDataPath('themes', true, $app));
                    waFiles::copy(
                        $this->data['backup_loc'] . 'themes/' . $app . '/public', 
                        wa()->getDataPath('themes', true, $app));
                }
                if (file_exists($this->data['backup_loc'] . 'themes/' . $app . '/protected')) {
                    waFiles::delete(wa()->getAppPath('themes', $app));
                    waFiles::copy(
                        $this->data['backup_loc'] . 'themes/' . $app . '/protected', 
                        wa()->getAppPath('themes', $app));
                }
            }
            $this->data['thm'] = true;
            $this->data['info'][9] = _w('App themes have been restored.');
            return true;
        }
        return true;
    }
    
    private function mysqldump() {
        if (easybackupHelper::shell_access() && easybackupHelper::command_available('mysqldump')) {
            @set_time_limit(1480);
            $db = waSystem::getInstance()->getConfig()->getDatabase();
            waFiles::create($this->data['backup_dest'] . 'db/database.sql');
            $command = 'mysqldump -h ' . $db['default']['host'] .
    			' -u ' . $db['default']['user'] . 
    			' --password=' . $db['default']['password'] . 
    			' ' . $db['default']['database'] . ' > ' . $this->data['backup_dest'] . 'db/database.sql';
            exec($command, $output, $return_val);
            if ($return_val === 0) {
                $this->data['db']['current'] = $this->data['db']['count'] = 0;
                $this->data['info'][4] = _w('Database dumped');
                $data_model = new waModel();
                $tblist = array();
                $tables = $data_model->query('SHOW TABLES')->fetchAll();
                foreach ($tables as $k => $table) {
                    $tblist[] = $table[key($tables[0])];
                }
                if (!waFiles::write($this->data['backup_dest'] . 'db/tblist', serialize($tblist))) {
                    throw new Exception(_w('Database backup file write error, check access rights.'));
                }
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    private function mysqlrestore() {
        if (easybackupHelper::shell_access() && easybackupHelper::command_available('mysql')) {
            @set_time_limit(1480);
            $db = waSystem::getInstance()->getConfig()->getDatabase();
            $command = 'mysql -h ' . $db['default']['host'] . ' -u ' .  $db['default']['user'] .
                ' --password=' . $db['default']['password'] .
                ' ' . $db['default']['database'] . ' < ' . $this->data['backup_loc'] . 'db/database.sql';
            exec($command);
            $this->data['db']['current'] = $this->data['db']['count'] = 0;
            return true;
        } else {
            return false;
        }
    }

    private function error($message, $type = '')
    {
        waLog::log($message, 'easybackup/backup_error.log');
        $result = array(
            'error' => $message,
        );
        if ($type == 'restore') {
            $result['rescue'] = easybackupHelper::restoreBckp();
        }
        if ($type == 'restorebckp') {
            $result['rescue'] = 'failed';
        }
        $this->getResponse()->addHeader('Content-type', 'application/json');
        $this->getResponse()->sendHeaders();
        echo json_encode($result);
    }
}