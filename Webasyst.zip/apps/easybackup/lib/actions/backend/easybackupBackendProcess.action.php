<?php

class easybackupBackendProcessAction extends waViewAction
{
    public function execute()
    {
        $action = waRequest::post('action', 'download');
        $backup = waRequest::post('backup');
        $message = 'OK';
        switch ($action) {
            case 'checkftp':
                $server = waRequest::post('server');
                $port = (waRequest::post('port') == '') ? 21 : waRequest::post('port');
                $login = (waRequest::post('login') == '') ? 'anonymous' : waRequest::post('login');
                $password = waRequest::post('password');
                $path = waRequest::post('path');
                $connect = ftp_connect($server, $port);
                if (!$connect) {
                    $message = json_encode('Connection to server failed');
                    break;
                }
                if (@ftp_login($connect, $login, $password)) {
                    if ($path == '' || @ftp_chdir($connect, $path)) {
                        $asm = new waAppSettingsModel();
                        $asm->set('easybackup', 'server', $server);
                        $asm->set('easybackup', 'port', $port);
                        $asm->set('easybackup', 'login', $login);
                        $asm->set('easybackup', 'password', $password);
                        $asm->set('easybackup', 'path', $path);
                        $message = json_encode('OK');
                    } 
                    else {
                        $message = json_encode("Can't switch to this folder");
                    }        
                } else {
                    $message = json_encode('Wrong connection credentials');
                }
                break;
            case 'download':
                if (!$this->getRights('download')) throw new waRightsException(_ws('Access denied'));
                $backup = waRequest::get('backup');
                $arch_filename = wa()->getDataPath('backup/', false, 'easybackup') . $backup . '/' . $backup;
                if (file_exists($arch_filename . '.zip')) {
                    waFiles::readFile($arch_filename . '.zip', $backup . '.zip');
                    // waFiles::delete($arch_filename . '.zip');
                } elseif (file_exists($arch_filename . '.tar.gz')) {
                    waFiles::readFile($arch_filename . '.tar.gz', $backup . '.tar.gz');
                    // waFiles::delete($arch_filename . '.tar.gz');
                }
                break;
            case 'compress':
                if (!$this->getRights('download')) throw new waRightsException(_ws('Access denied'));
                $archive_path = wa()->getDataPath('backup/', false, 'easybackup') . $backup . '/' . $backup . '.temp';
                if (file_exists($archive_path)) waFiles::delete($archive_path);
                $result = easybackupHelper::tarData(wa()->getDataPath('backup/', false, 'easybackup') . $backup, $archive_path);
                if ($result) rename($archive_path, wa()->getDataPath('backup/', false, 'easybackup') . $backup . '/' . $backup . '.tar.gz');
                $message = 'OK';
                break;
            case 'savesettings':
                if (!$this->getRights('cron')) throw new waRightsException(_ws('Access denied'));
                $asm = new waAppSettingsModel();
                $asm->set('easybackup', 'cronstring', $backup);
                $asm->set('easybackup', 'rotate_num', waRequest::post('rotate_num'));
                $asm->set('easybackup', 'ftp', waRequest::post('ftp'));
                $asm->set('easybackup', 'token', waRequest::post('token'));
                $asm->set('easybackup', 'yad', waRequest::post('yad'));
                
                break;
            case 'delete':
                if (!$this->getRights('delete')) throw new waRightsException(_ws('Access denied'));
                waFiles::delete(wa()->getDataPath('backup/', false, 'easybackup') . $backup);
                break;
            case 'deletebckp':
                if (!$this->getRights('restore')) throw new waRightsException(_ws('Access denied'));
                $data_model = new waModel();
                $tables = $data_model->query('SHOW TABLES')->fetchAll();
                foreach ($tables as $k => $table) {
                    if (substr($table[key($tables[0])], 0, 4) == 'bckp') {
                        $data_model->exec('DROP TABLE ' . $table[key($tables[0])]);
                    }
                }
                if (file_exists(wa()->getDataPath('/bckp_products', true, 'shop'))) {
                    waFiles::delete(wa()->getDataPath('/bckp_products', true, 'shop'));
                }
                if (file_exists(wa()->getDataPath('/bckp_edt', true, 'shop'))) {
                    waFiles::delete(wa()->getDataPath('/bckp_edt', true, 'shop'));
                }
                if (file_exists(wa()->getDataPath('/bckp_products', false, 'shop'))) {
                    waFiles::delete(wa()->getDataPath('/bckp_products', false, 'shop'));
                }
                if (file_exists(wa()->getConfig()->getRootPath() . '/bckp_wa-config')) {
                    waFiles::delete(wa()->getConfig()->getRootPath() . '/bckp_wa-config');
                }
                $message = 'deleted';
                break;

            case 'restorebckp':
                if (!$this->getRights('restore')) throw new waRightsException(_ws('Access denied'));
                $message = easybackupHelper::restoreBckp();
                break;

            case 'getsize':
                if (!$this->getRights('backup')) throw new waRightsException(_ws('Access denied'));
                $asm = new waAppSettingsModel();
                $response = easybackupHelper::getImgSize();
                $response['db'] = easybackupHelper::getDbSize();
                $message = json_encode($response);
                $asm->set('easybackup', 'size', $message);
                break;
        }
        if (isset($message)) {
            $this->view->assign('message', $message);
        }
    }
}
