<?php
class easybackupBackendRestoreAction extends waViewAction
{
    public function execute()
    {
        $rights = $this->getRights();
        $check = isset($rights['restore'])||isset($rights['download'])||isset($rights['delete'])||$this->getUser()->isAdmin('easybackup');
        if (!$check) throw new waRightsException(_ws('Access denied'));
        $data_path = wa()->getDataPath('backup', false, 'easybackup');
        $backup_list = waFiles::listdir($data_path);
        arsort($backup_list);
        $list = array();
        foreach ($backup_list as $k => $b) {
            if ($b == 'current') {
                continue;
            }
            $icons = '';
            if (strstr($b, 'wac')) {
                $icons .= '<i class="icon16 settings" title="'._w('Configuration').'"></i>';
            }
            if (strstr($b, 'db')) {
                $icons .= '<i class="icon16 archive-text" title="'._w('Database').'"></i>';
            }
            if (strstr($b, 'img')) {
                $icons .= '<i class="icon16 image" title="'._w('Product images - original').'"></i>';
            }
            if (strstr($b, 'tmb')) {
                $icons .= '<i class="icon16 pictures" title="'._w('Product images - thumbs').'"></i>';
            }
            if (strstr($b, 'edt')) {
                $icons .= '<i class="icon16 edit" title="'._w('WYSIWYG-editor images').'"></i>';
            }
            if (strstr($b, 'thm')) {
                $icons .= '<i class="icon16 design" title="'._w('Apps themes').'"></i>';
            }
            $list[$k]['archive'] =  (file_exists($data_path . '/' . $b . '/' . $b . '.zip') 
                                    || file_exists($data_path . '/' . $b . '/' . $b . '.tar.gz'));
            
            $list[$k]['file'] = $b;
            $list[$k]['icons'] = $icons;
            $list[$k] += json_decode(file_get_contents($data_path.'/' . $b . '/info'), true);
        }
        $this->view->assign('zip', extension_loaded('zip'));
        $this->view->assign('list', $list);
        $this->view->assign('bckp', easybackupHelper::checkBckp());
        $this->view->assign('rights', easybackupHelper::getUserRights());
    }
}
