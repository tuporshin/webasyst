<?php

class easybackupBackendLayout extends waLayout
{
    public function execute()
    {
        $root_url = wa()->getRootUrl();
        $this->view->assign('root_url', $root_url);
        $this->view->assign('rights', easybackupHelper::getUserRights());
        $this->loc();
    }
    
    private function loc(){
         $strings = array();
        // Application locale strings
        foreach(array(
            "Please, wait the process to finish.",
            "Select at least one param.",
            "Remove temporary copies.",
            "Confirm remove.",
            "Error on restore action.",
            "Restore error. Try once more and contact the developer. Temporary copies were succesfully restored.",
            "Restore error. Temporary copies can't be restored, you can use hosting tools to restore.",
            "Init process error. Try once more and contact the developer: ",
            "Backup process error. Backup is not created, try once more and contact the developer: ",
            "Temporary copies have been restored.",
            "Restore error. Try once more and contact the developer. Temporary copies were succesfully restored.",
            "Temporary copies are restored.",
            "Confirm restore.",
            "Items to restore",
            "Cancel",
            "Restore",
        ) as $s) {
            $strings[$s] = _w($s);
        }
        $this->view->assign('strings', $strings ? $strings : new stdClass()); // stdClass is used to show {} instead of [] when there's no strings
    }
}
