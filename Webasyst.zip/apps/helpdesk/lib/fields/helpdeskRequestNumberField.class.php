<?php

class helpdeskRequestNumberField extends helpdeskRequestStringField
{
}

// EOF