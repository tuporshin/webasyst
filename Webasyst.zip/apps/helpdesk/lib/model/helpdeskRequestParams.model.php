<?php
class helpdeskRequestParamsModel extends waModel
{
    protected $table = 'helpdesk_request_params';
}
