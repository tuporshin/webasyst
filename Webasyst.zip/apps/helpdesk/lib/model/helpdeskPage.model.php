<?php

class helpdeskPageModel extends waPageModel
{
    protected $app_id = 'helpdesk';
    protected $table = 'helpdesk_page';
}
