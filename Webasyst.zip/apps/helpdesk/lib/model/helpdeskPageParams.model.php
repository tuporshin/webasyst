<?php

class helpdeskPageParamsModel extends waPageParamsModel
{
    protected $table = 'helpdesk_page_params';
}
