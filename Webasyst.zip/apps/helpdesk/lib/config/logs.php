<?php

return array(
    'request_created' => array(
        'name' => /*_w*/('created a new request')
    ),
    'perform_action' => array(
        'name' => /*_w*/('performed an action with request')
    ),
);
