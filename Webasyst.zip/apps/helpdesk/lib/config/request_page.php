<?php

return array(
    'status' => array(
        'id' => 'status',
        'name' => 'Status',     //_w('Status')
        'value' => 'Status',    // _w('Status')
        'place' => 'right'
    ),
    'assigned' => array(
        'id' => 'assigned',
        'name' => 'Assigned',       // _w('Assigned')
        'value' => 'Name',           // _w('Name')
        'place' => 'right'
    ),
    'tags' => array(
        'id' => 'tags',
        'name' => 'Tags',           // _w('Tags')
        'value' => 'Tags',           // _w('Tags')
        'place' => 'right'
    ),
);
