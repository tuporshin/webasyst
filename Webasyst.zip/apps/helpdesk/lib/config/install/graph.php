<?php
// Coordinates for workflow settings page for pre-installed forkflow
return array (
  1 => 
  array (
    'state' => 
    array (
      'archive' => 
      array (
        'x' => 449,
        'y' => 146,
      ),
      'new' => 
      array (
        'x' => 70,
        'y' => 213,
      ),
      'processing' => 
      array (
        'x' => 259,
        'y' => 420,
      ),
      'deleted' => 
      array (
        'x' => 1,
        'y' => 437,
      ),
    ),
  ),
);