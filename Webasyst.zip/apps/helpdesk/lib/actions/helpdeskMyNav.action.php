<?php
/**
 * Interface for customer portal navigation block.
 * !!! insert a link to online docs here when it is available
 */
class helpdeskMyNavAction extends waMyNavAction
{
}
