<?php

class helpdeskFrontendUploadImageController extends helpdeskFilesUploadimageController
{
} 