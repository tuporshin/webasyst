<?php
/**
 * Receives POST data from forms that create new requests in frontend.
 */
class helpdeskFrontendFormController extends helpdeskRequestsSaveController
{
    // nothing to override...
}

