<?php

class helpdeskFrontendFormBackgroundController extends waJsonController
{
    public function execute()
    {
        // now, just for update sesstion
    }
}

