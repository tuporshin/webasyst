<?php

waFiles::delete($this->getAppPath('lib/classes/filesSourcePlugin.class.php'));