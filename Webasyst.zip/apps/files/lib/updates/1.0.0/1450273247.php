<?php

waFiles::delete($this->getAppPath('templates/include.files.html'));