<?php

waFiles::delete($this->getAppPath('lib/classes/filesSource.class.php'));
waFiles::delete($this->getAppPath('lib/classes/filesAppSource.class.php'));