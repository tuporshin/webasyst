<?php

waFiles::delete($this->getAppPath('lib/actions/backend/filesBackendInfo.action.php'));
waFiles::delete($this->getAppPath('templates/actions/backend/BackendInfo.html'));