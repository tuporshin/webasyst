<?php

class filesFrontendLayout extends waLayout
{
    public function execute()
    {
        $this->setThemeTemplate('index.html');
    }
}
