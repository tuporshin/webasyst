<?php

class filesDefaultLayout extends waLayout
{
    public function execute()
    {
        $this->executeAction('sidebar', new filesBackendSidebarAction());
        $this->executeAction('uploader', new filesUploadAction());
        $this->assign('js_options', filesApp::inst()->getConfig()->getOptionsForJs());

        $sm = new filesSourceModel();
        $this->assign('source_count', $sm->countAllSources());

        /**
         * Custom HTML and JS from plugins
         * @event backend_layout_blocks
         * @return array[string]string $return[%plugin_id%]
         */
        $params = array(
            'layout' => $this
        );
        $backend_layout_blocks = wa('files')->event('backend_layout', $params);


        $this->assign('backend_layout_blocks', $backend_layout_blocks);

    }
}
