<?php

interface filesFileRelatedInterface
{
    public function onDeleteFile($files);
    public function getRelatedFields();
}