<?php

return array(
    'params' => array(
        /*
        'frontend_type' => array(
            'name' => _w('Frontend type'),
            'type' => 'radio_select',
            'items' => array(
                0 => array(
                    'name' => _w('Published files'),
                    'description' => _w('Published files'),
                ),
                1 => array(
                    'name' => _w('WebDav'),
                    'description' => _w('WebDav'),
                )
            )
        ),
        */
    )
);
