<?php

return array(
    'files_upload' => array('name' => /* _w */('uploaded')),
    'folder_create' => array('name' => /* _w */('created new folder')),
    'storage_create' => array('name' => /* _w */('created new storage')),
    'rename' => array('name' => /* _w */('renamed')),
    'move' => array('name' => /* _w */('moved')),
    'copy' => array('name' => /* _w */('duplicated')),
    'delete' => array('name' => /* _w */('deleted')),
    'restore' => array('name' => /* _w */('restored')),
);
