<?php

$_filesInstaller = new filesInstaller();
$_filesInstaller->installAll();