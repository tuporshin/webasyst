<?php

return array(
    0 => array(
        '' => 'frontend',
        'folder/<hash>' => 'frontend/folder',
        'file/<hash>' => 'frontend/file'
    ),
    1 => array(
        '' => 'frontend',
    )
);
