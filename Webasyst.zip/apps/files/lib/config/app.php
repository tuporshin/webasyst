<?php

return array (
    'name' => 'Files',
    'icon' => array(
        24 => 'img/files24.png',
        48 => 'img/files.png',
        96 => 'img/files96.png',
    ),
    'version' => '1.1.1',
    'sash_color' => '#25b5ed',
    'rights' => true,
    'csrf' => true,
    'plugins' => true,
    'frontend' => true,
    'themes' => true,
    'routing_params' => array(
        'private' => true,
    ),
);
