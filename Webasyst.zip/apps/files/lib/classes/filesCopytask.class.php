<?php

class filesCopytask
{
    /**
     * @var filesFileModel
     */
    private $model;

    /**
     * @var filesCopytaskModel
     */
    protected $copytask;

    protected $number_of_tasks;

    protected $chunk_size;

    protected $max_execution_time;

    protected $max_steps;

    protected $steps_passed;

    protected $execution_start;

    protected $options;

    protected $copytask_caller;

    public function __construct($number_of_tasks = 1, $options = array()) {
        $this->model = new filesFileModel();
        $this->copytask = new filesCopytaskModel();
        $this->number_of_tasks = $number_of_tasks;

        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
        $this->copytask_caller = $trace[1];

        // the most effective and safe chunk size (equals php inner buffer size for stream operations)
        $this->chunk_size = 256 * 1024;
        if (!empty($options['chunk_size'])) {
            $this->chunk_size = (int) $options['chunk_size'];
        }

        if ($this->chunk_size <= 0) {
            throw new filesException("Chunk size must be greater 0");
        }

        if (!empty($options['max_execution_time'])) {
            $this->max_execution_time = (int) $options['max_execution_time'];
        } else {
            $this->max_execution_time = (int) ini_get('max_execution_time');
        }
        if ($this->max_execution_time <= 0) {
            $this->max_execution_time = 120;
        }

        if (isset($options['max_steps']) && wa_is_int($options['max_steps'])) {
            $this->max_steps = (int) $options['max_steps'];
        }

        $this->execution_start = time();

        $this->steps_passed = 0;

        $this->options = $options;
    }

    public function execute()
    {
        /**
         * @event start_copy_tasks
         */
        wa('files')->event('start_copy_tasks');
        for ($i = 0; $i < $this->number_of_tasks; $i += 1) {
            $this->executeOne();
        }
    }

    protected function executeOne()
    {
        if ($this->copytask->countAll() <= 0) {
            return;
        }
        $this->copytask->prolongLocks();
        $task = $this->getTask();
        if (!$task) {
            return;
        }
        $res = $this->performTask($task);
        $this->clearTaskResources($task);
        return $res;
    }

    protected function getTask()
    {
        $process_id = ifset($this->options['process_id']);
        $task = $this->copytask->getTask($this->max_execution_time, $process_id);
        if (!$task) {
            return null;
        }

        $this->copytask->incrementRetriesOfTask($task['target_id']);

        $date = date('Y-m-d H:i:s');
        $this->copytask->updateById($task['target_id'], array( 'process_datetime' => $date ));
        $task['process_datetime'] = $date;

        $src_file = $this->model->getFile($task['source_id']);
        if (!$src_file) {
            $this->deleteCopytask($task);
            return null;
        }

        $trg_file = $this->model->getFile($task['target_id']);
        if (!$trg_file) {
            $this->deleteCopytask($task);
            return null;
        }

        $task['target_file'] = $trg_file;
        $task['source_file'] = $src_file;

        $task['source_file']['source'] = filesSource::factory($task['source_file']['source_id']);
        $task['target_file']['source'] = filesSource::factory($task['target_file']['source_id']);

        $params = array(
            'copytask_file_role' => 'source',
            'task' => $task
        );
        $params = $task['source_file']['source']->beforePerformCopytask($params);
        if (!$params) {
            $this->deleteCopytask($task);
            return null;
        }
        $task['source_file'] = $params['task']['source_file'];
        $task['target_file'] = $params['task']['target_file'];

        $params = array(
            'copytask_file_role' => 'target',
            'task' => $task
        );
        $params = $task['target_file']['source']->beforePerformCopytask($params);
        if (!$params) {
            $this->deleteCopytask($task);
            return null;
        }
        $task['target_file'] = $params['task']['target_file'];

        return $task;
    }

    protected function clearTaskResources($task)
    {
        @fclose($task['source_file']['stream']);
        @fclose($task['target_file']['stream']);
        $this->copytask->unlockTask($task['target_id']);
    }

    protected function isTaskCompleted($task)
    {
        return $task['offset'] >= $task['target_file']['size'];
    }

    protected function getFile($id, $check_exist = true)
    {
        $file = $this->model->getFile($id);

        if ($check_exist && file_exists($file['path'])) {
            $file['exists'] = true;
        } else {
            $file['exists'] = false;
        }

        $file['filesize'] = 0;
        if ($file['exists']) {
            clearstatcache();
            $file['filesize'] = (int) @filesize($file['path']);
        }

        return $file;
    }

    protected function performTask($task)
    {
        $complete = $this->isTaskCompleted($task);

        // run copy process
        while (!$complete) {

            $res = $this->performOneChunkOfTask($task);
            if (!$res) {
                break;
            }

            $task = $res;
            $complete = $this->isTaskCompleted($task);
            if ($complete) {
                break;
            }

            $this->steps_passed += 1;
            if (wa_is_int($this->max_steps) && $this->steps_passed >= $this->max_steps) {
                break;
            }

            $executed_time = time() - $this->execution_start;
            if ($executed_time >= $this->max_execution_time - 5) {
                break;
            }

            sleep(1);
        }

        if ($complete) {
            $this->onCompleteCopyTask($task);
        }

        return $complete;
    }

    protected function performOneChunkOfTask($task)
    {
        try {
            $chunk = $task['source_file']['source']->downloadChunk($task['source_file'], $task['offset'], $this->chunk_size);
        } catch (filesSourceException $e) {
            $this->deleteCopytask($task);
            return false;
        }

        $task['offset'] = $task['target_file']['source']->uploadChunk($task['target_file'], $task['offset'], $chunk);

        // save offset
        $this->copytask->updateById($task['target_id'], array( 'offset' => $task['offset'] ));

        return $task;
    }

    protected function onCompleteCopyTask($task)
    {
        $params = array(
            'copytask_file_role' => 'source',
            'task' => $task
        );
        $params = $task['source_file']['source']->afterPerformCopytask($params);

        // source method afterPerformCopytask is allowed to change target_file,
        // because we can apply some info (for example 'size')
        // but it is not allowed change source file - because source_file is source, it must be hold "old"
        $task['target_file'] = $params['task']['target_file'];

        $params = array(
            'copytask_file_role' => 'target',
            'task' => $task
        );
        $params = $task['target_file']['source']->afterPerformCopytask($params);

        // source method afterPerformCopytask is allowed to change target_file,
        // because we can apply some info (for example 'size')
        // but it is not allowed change source file - because source_file is source, it must be hold "old"
        $task['target_file'] = $params['task']['target_file'];

        // own copytask changes
        $task['target_file']['update_datetime'] = date('Y-m-d H:i:s');
        $task['target_file']['in_copy_process'] = 0;

        // old version on target file
        $file = $this->model->getById($task['target_file']['id']);

        // calculate what to update
        $update = array();
        foreach ($file as $field => $orig_value) {
            if ($task['target_file'][$field] != $orig_value) {
                $update[$field] = $task['target_file'][$field];
            }
        }

        // so, update
        $this->model->updateById($task['target_file']['id'], $update);


        // mean copytask for moving file - so delete source file
        if ($task['is_move']) {

            $tasks_count = $this->copytask->countByField(array('process_id' => $task['process_id']));

            // delete first copytask to release locks
            $this->copytask->delete($task['target_file']['id']);

            // delete source file
            $this->model->delete($task['source_file']['id']);

            // delete 'held' folders, see description of method
            if ($tasks_count <= 1 && empty($this->options['not_delete_held_move_folders'])) {
                $this->model->deleteHeldMoveFolders();
            }

        } else {
            $this->copytask->delete($task['target_file']['id']);
        }

    }

    protected function deleteCopytask($task)
    {
        $this->copytask->delete($task['target_id']);
        $this->model->delete($task['target_id']);
        if ($task['is_move']) {
            $this->model->updateById($task['source_id'], array(
                'in_copy_process' => 0
            ));
        }
    }
}