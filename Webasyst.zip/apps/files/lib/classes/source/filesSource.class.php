<?php

/**
 * Class filesSource
 *
 * All that methods is proxy-methods to filesSourceProvider class
 *
 * @method string|int getId()
 * @method array getInfo()
 * @method int getContactId()
 * @method mixed getField(string $field)
 * @method string getType()
 * @method void setType()
 * @method string getIconUrl()
 * @method void setToken(string $token)
 * @method string getToken()
 * @method bool hasValidToken()
 * @method void markTokenAsInvalid()
 * @method void setSynchronizeDatetime()
 * @method string|null getSynchronizeDatetime()
 * @method array getParams()
 * @method string|null getParam($key)
 * @method void setParam(string $key, mixed $value)
 * @method void addParams(array $params)
 * @method void setParams(array $params)
 * @method int getStorageId()
 * @method int|null getFolderId()
 * @method void setName()
 * @method string getName()
 * @method waContact getOwner()
 * @method array getPath()
 * @method bool isMounted(bool $check_existing = true)
 * @method mount(array $mount)
 * @method pauseSync()
 * @method unpauseSync()
 * @method string getAccountInfoHtml()
 * @method array getAccountInfo()
 * @method bool hasAccountInfo()
 *
 * @method array beforeAdd(array $params)
 * @method array afterAdd(array $params)
 *
 * @method array beforeReplace(array $params)
 * @method array afterReplace(array $params)
 *
 * @method array beforeCopy(array $params)
 * @method array afterCopy(array $params)
 *
 * @method array beforeRename(array $params)
 * @method array afterRename(array $params)
 *
 * @method array beforeDelete(array $params)
 * @method array afterDelete(array $params)
 *
 * @method array beforeMove(array $params)
 * @method array afterMove(array $params)
 *
 * @method array beforeMoveToTrash(array $params)
 * @method array afterMoveToTrash(array $params)
 *
 * @method string getFilePath(array $file)
 * @method array[]string getFilePhotoUrls(array $file)
 *
 * @method mixed download(array $file, string $type = filesSource::DOWNLOAD_STDOUT, array $options = array())
 *
 * @method downloadChunk(array $file, int $offset, int $chunk_size)
 * @method uploadChunk(array $file, int $offset, string $chunk)
 *
 * @method beforePullingStart()
 * @method array pullChunk(array $progress_info = array())
 * @method afterPullingEnd()
 * @method array syncData()
 *
 * @method array|null getAttachmentInfo(array $params)
 */
final class filesSource
{
    const DOWNLOAD_STDOUT = 'stdout';
    const DOWNLOAD_FILEPATH = 'filepath';
    const DOWNLOAD_STREAM = 'stream';

    const PROVIDER_TYPE_APP = 'filesSourceAppProvider';
    const PROVIDER_TYPE_NULL = 'filesSourceNullProvider';

    /**
     * @var filesModel[]
     */
    private static $models;

    /**
     * @var filesSourceProvider[]
     */
    private static $sources = array();

    /**
     * @var filesSourceProvider
     */
    private $provider;

    /**
     * @param string|int|array $id
     * @return filesSource|filesSource[]
     */
    public static function factory($id)
    {
        $ids = array_unique(array_map('trim', (array)$id));

        #get integer ids
        $exists_ids = array_filter(array_map('intval', $ids));
        #and use not cached ids
        $exists_ids = array_diff($exists_ids, array_keys(self::$sources));
        $items = array();

        if ($exists_ids) {

            if ($items = self::getSourceModel()->getById($exists_ids)) {
                foreach ($items as &$item) {
                    $item['params'] = array();
                }
                unset($item);

                foreach (self::getSourceParamsModel()->getByField('source_id', array_keys($items), true) as $param) {
                    //TODO json_decode?
                    $items[$param['source_id']]['params'][$param['name']] = $param['value'];
                }
            }
        }

        $sources = array();
        foreach ($ids as $_id) {
            if ($_id === self::PROVIDER_TYPE_APP) {
                $sources[$_id] = new filesSource(new filesSourceAppProvider());
            } else if ($_id === self::PROVIDER_TYPE_NULL || $_id === null) {
                $sources[$_id] = new filesSource(new filesSourceNullProvider());
            } else if (!isset(self::$sources[$_id])) {
                $info = ifset($items[$_id], array());
                $type = ($info && isset($info['type'])) ? $info['type'] : $_id;
                $info['type'] = $type;

                $class_name = self::getClass($type);
                if (empty($info['id']) && $class_name !== 'filesSourceAppProvider') {
                    $info['id'] = $info['type'];
                }
                $provider = new $class_name($info);
                $sources[$_id] = new filesSource($provider);
            } else {
                $sources[$_id] = self::$sources[$_id];
            }
            self::$sources[$_id] = $sources[$_id];
        }
        return is_array($id) ? $sources : $sources[$id];
    }

    public static function factoryApp()
    {
        return self::factory(self::PROVIDER_TYPE_APP);
    }

    public static function factoryNull()
    {
        return self::factory(self::PROVIDER_TYPE_NULL);
    }

    public function isNull()
    {
        return $this->provider instanceof filesSourceNullProvider;
    }

    public static function factoryByProvider($provider)
    {
        if ($provider instanceof filesSourceProvider) {
            return new filesSource($provider);
        }
        throw new waException("Illegal provider");
    }

    public function isApp()
    {
        return $this->provider instanceof filesSourceAppProvider;
    }

    /**
     * @param string $type
     * @return string
     */
    private static function getClass($type)
    {
        $class_name = 'filesSourceNullProvider';
        if ($type === self::PROVIDER_TYPE_APP || $type === '0' || $type === 0 || $type === '') {
            $class_name = 'filesSourceAppProvider';
        }

        if ($type) {
            $type = strtolower(trim($type));
            $name = 'files'.filesApp::ucfirst($type).'SourceProvider';
            if (class_exists($name)) {
                $class_name = $name;
            }
        }

        return $class_name;
    }

    /**
     * @return filesSourceModel
     */
    private static function getSourceModel()
    {
        return ifset(self::$models['source'], new filesSourceModel());
    }

    /**
     * @return filesSourceParamsModel
     */
    private static function getSourceParamsModel()
    {
        return ifset(self::$models['source_params'], new filesSourceParamsModel());
    }

    /**
     * @return filesFileModel
     */
    private static function getFileModel()
    {
        return ifset(self::$models['file'], new filesFileModel());
    }

    /**
     * filesSource constructor.
     * @param filesSourceProvider $provider
     */
    protected function __construct(filesSourceProvider $provider)
    {
        $this->provider = $provider;
    }

    public function getProviderName()
    {
        return $this->provider->getTitleName();
    }

    /**
     * @return filesSourceProvider
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * @return filesSource|filesSource[]
     */
    public function save()
    {
        $provider = $this->provider->save();
        unset(self::$sources[$provider->getId()]);
        return self::factory($provider->getId());
    }

    public function delete()
    {
        $id = $this->provider->getId();
        if ($this->provider->delete()) {
            self::$sources[$id] = null;
        }
    }

    public function inSync()
    {
        return filesSourceSync::inSync($this->provider->getId());
    }

    public function beforePerformCopytask($params)
    {
        $orig_files = array(
            'source_file' => $params['task']['source_file'],
            'target_file' => $params['task']['target_file']
        );
        $params = $this->provider->beforePerformCopytask($params);
        $res_files = array(
            'source_file' => $params['task']['source_file'],
            'target_file' => $params['task']['target_file']
        );
        $res_files = $this->restoreImmutableFileFields($res_files, $orig_files);
        $params['task']['source_file'] = $res_files['source_file'];
        $params['task']['target_file'] = $res_files['target_file'];
        return $params;
    }

    public function afterPerformCopytask($params)
    {
        $orig_files = array(
            'source_file' => $params['task']['source_file'],
            'target_file' => $params['task']['target_file']
        );
        $params = $this->provider->afterPerformCopytask($params);
        $res_files = array(
            'source_file' => $params['task']['source_file'],
            'target_file' => $params['task']['target_file']
        );
        $res_files = $this->restoreImmutableFileFields($res_files, $orig_files);
        $params['task']['source_file'] = $res_files['source_file'];
        $params['task']['target_file'] = $res_files['target_file'];
        return $params;
    }

    /**
     * Proxy all rest methods to under-layer provider
     * @param $name
     * @param $arguments
     * @return mixed|null|void
     * @throws Exception
     */
    public function __call($name, $arguments)
    {
        if (is_callable(array($this->provider, $name))) {
            try {

                if (preg_match('/before(.+)$/', $name, $m)) {
                    return $this->beforeOperation($m[1], $arguments);
                }

                return call_user_func_array(array($this->provider, $name), $arguments);
            } catch (filesSourceTokenInvalidException $e) {

                $this->markTokenAsInvalid();
                $this->unpauseSync();

                if ($name === 'syncData') {
                    $this->logException($e, $name);
                    return;
                }

                if (wa()->getEnv() === 'backend') {
                    if ($this->getOwner()->getId() == wa()->getUser()->getId()) {
                        $url = wa()->getAppUrl('files') . '#/source/' . $this->getId();
                        if ($name !== 'download') {
                            wa()->getResponse()->addHeader('X-Wa-Files-Location', $url);
                        } else {
                            wa()->getResponse()->redirect($url);
                        }
                    }
                }

            } catch (filesSourceFolderAlreadyExistsException $e) {

                $this->unpauseSync();

                // just ignore, folder already exists, so just keep silence
                $first = reset($arguments);
                if (isset($first['type']) && $first['type'] === filesFileModel::TYPE_FOLDER) {
                    return $first;
                }


            } catch (Exception $e) {

                $this->unpauseSync();

                if ($name === 'syncData') {
                    $this->logException($e, $name);
                    return;
                }
                throw $e;
            }
        }
        return null;
    }

    private function beforeOperation($operation, $arguments)
    {
        if (count($arguments) <= 0) {
            return;
        }
        $params = $arguments[0];
        if (!is_array($params)) {
            return $params;
        }

        $method = "before{$operation}";
        if (!method_exists($this->provider, $method)) {
            return $arguments[0];
        }

        $params_files = null;
        $params_file = null;
        if (isset($params['files']) && is_array($params['files'])) {
            $params_files = $params['files'];
        }
        if (isset($params['file']) && is_array($params['file'])) {
            $params_file = $params['file'];
        }

        if (!$params_files && !$params_file) {
            return $params;
        }

        // call provider method
        $res = call_user_func_array(array($this->provider, $method), $arguments);

        if (!empty($res['files'])) {
            $res['files'] = $this->restoreImmutableFileFields($res['files'], $params_files);
        }

        if (!empty($res['file'])) {
            $orig_files = array(
                0 => $params_file
            );
            $res_files = array(
                0 => $res['file']
            );
            $res_files = $this->restoreImmutableFileFields($res_files, $orig_files);
            $res['file'] = $res_files[0];
        }

        return $res;
    }

    private function restoreImmutableFileFields($res_files, $orig_files)
    {
        // restore immutable fields
        $immutable_fields = $this->getImmutableFields();
        foreach ($res_files as $id => &$res_file) {
            if (is_array($res_file) && isset($orig_files[$id])) {
                foreach ($immutable_fields as $field) {
                    if (array_key_exists($field, $orig_files[$id])) {
                        $res_file[$field] = $orig_files[$id][$field];
                    } else {
                        if (array_key_exists($field, $res_file)) {
                            unset($res_file[$field]);
                        }
                    }
                }
            }
        }
        unset($res_file);

        return $res_files;
    }

    public function getImmutableFields()
    {
        return array('id', 'source_id', 'parent_id', 'type', 'depth', 'left_key', 'right_key');
    }


    private function logException($e, $method_name)
    {
        $w = date('W');
        $y = date('Y');
        waLog::log($e->getTraceAsString() . PHP_EOL, "files/exceptions/{$y}/{$w}/{$method_name}.log");
    }
}
