<?php

/**
 * Class filesSourceSync
 *
 * All that methods is proxy-methods to filesSourceSyncDriver class
 *
 * @method void append(array $items = array())
 * @method int getChunkSize()
 * @method int getTotalCount()
 * @method array process(array $params = array())
 *
 */
final class filesSourceSync
{
    /**
     * @var filesSourceSyncDriver
     */
    protected $driver;

    /**
     * @var int number of items to process
     */
    protected $chunk_size = 100;

    public function __construct(filesSource $source, $options = array())
    {
        if (empty($options['chunk_size'])) {
            $options['chunk_size'] = $this->chunk_size;
        }
        $options['chunk_size'] = (int) $options['chunk_size'];

        // factor driver
        $type = $source->getType();
        $class_name = 'files' . filesApp::ucfirst($type) . 'SourceSyncDriver';

        if (class_exists($class_name)) {
            $this->driver = new $class_name($source, $options);
        } else {
            $this->driver = new filesSourceSyncDefaultDriver($source, $options);
        }
    }

    /**
     * @param int|array[]int $source_id
     * @return bool|array[]bool
     */
    public static function inSync($source_id)
    {
        $sm = new filesSourceSyncModel();
        return $sm->inSync($source_id);
    }

    public function __call($name, $arguments)
    {
        if (is_callable(array($this->driver, $name))) {
            return call_user_func_array(array($this->driver, $name), $arguments);
        }
        return null;
    }
}