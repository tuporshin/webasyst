<?php

class filesSourceUnknownTypeException extends filesSourceException
{
    protected $message = 'Unknown type';
}