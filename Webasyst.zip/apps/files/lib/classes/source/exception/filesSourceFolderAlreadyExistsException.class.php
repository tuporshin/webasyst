<?php

class filesSourceFolderAlreadyExistsException extends filesSourceException
{
    protected $message = 'Folder already exists';
}