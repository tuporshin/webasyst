<?php

class filesSourceTokenInvalidException extends filesSourceException
{
    protected $message = 'Token is invalid';
}