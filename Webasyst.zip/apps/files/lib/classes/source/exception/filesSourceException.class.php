<?php

class filesSourceException extends waException
{
    protected $message = 'Unknown source exception';
}