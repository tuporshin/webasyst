<?php

class filesSourceFileAlreadyExistsException extends filesSourceException
{
    protected $message = 'File already exists';
}