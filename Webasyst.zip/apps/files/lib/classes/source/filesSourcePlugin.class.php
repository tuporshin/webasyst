<?php

abstract class filesSourcePlugin extends waPlugin
{
    const TOKEN_RECEIVING_METHOD_AUTO = 'auto';
    const TOKEN_RECEIVING_METHOD_MANUAL = 'manual';

    /**
     * @param $plugin_id
     * @return filesSourcePlugin|null
     */
    public static function factory($plugin_id)
    {
        $plugins = filesApp::inst()->getConfig()->getSourcePlugins();
        if (!isset($plugins[$plugin_id])) {
            return null;
        }
        $info = $plugins[$plugin_id];
        $class_name = $info['app_id'] . filesApp::ucfirst($info['id']) . 'Plugin';
        if (!class_exists($class_name)) {
            return null;
        }
        $plugin = new $class_name($info);
        if (!($plugin instanceof filesSourcePlugin)) {
            return null;
        }
        return $plugin;
    }

    public static function getPlugins()
    {
        static $plugins;
        if ($plugins === null) {
            $plugins = wa('files')->getConfig()->getPlugins();
            foreach ($plugins as $id => $plugin) {
                if (empty($plugin['source'])) {
                    unset($plugins[$id]);
                }
            }
        }
        return $plugins;
    }

    abstract public function authorizeBegin($source_id, $options = array());
    abstract public function authorizeEnd($options = array());

    public function getId()
    {
        return $this->id;
    }

    public function __get($name)
    {
        return $this->getSettings($name);
    }

    public function getIconUrl()
    {
        return $this->getPluginStaticUrl(true) . $this->info['icon'];
    }

    public function getCallbackUrl()
    {
        return self::getCallbackUrlById($this->getId());
    }

    public static function getCallbackUrlById($id)
    {
        return filesApp::getAbsoluteUrl() . '?module=source&action=authorize&authorize_end=1&id=' . $id;
    }

    public function getTokenReceivingMethod()
    {
        return self::TOKEN_RECEIVING_METHOD_AUTO;
    }

    public function getPath()
    {
        return wa('files')->getAppPath('plugins/' . $this->getId() . '/');
    }

    /**
     * @return bool
     */
    public function areAllRequiredSettingsFilled()
    {
        $config = $this->getSettingsConfig();
        $settings = $this->getSettings();
        foreach ($config as $key => $options) {
            if (!empty($options['required']) && empty($settings[$key])) {
                return false;
            }
        }
        return true;
    }
}