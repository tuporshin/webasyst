<?php

class filesFileStream
{
    /**
     * @var int
     */
    protected $position;

    /**
     * @var filesFileModel
     */
    static protected $fm;

    /**
     * @var array
     */
    protected $file;

    public function __construct()
    {
        if (self::$fm === null) {
            self::$fm = new filesFileModel();
        }
    }

    public function stream_open($path, $mode, $options, &$opened_path)
    {
        $parsed = parse_url($path);
        $id = (int) $parsed['host'];
        $item = self::$fm->getItem($id, false);
        if (!$item || $item['type'] !== filesFileModel::TYPE_FILE) {
            return false;
        }

        $this->file = $item;
        $this->file['source'] = filesSource::factory($this->file['id']);
        $this->position = 0;

        return true;
    }

    public function stream_read($count)
    {

    }
}