<?php

/**
 * Tabs with additional info in contact profile page.
 */
class filesContactsProfileTabHandler extends waEventHandler
{
    public function execute(&$params)
    {
        $contact_id = $params;

        $col = new filesCollection('', array(
            'filter' => array(
                'contact_id' => $contact_id
            )
        ));
        $total_count = $col->count();

        if ($total_count <= 0) {
            return null;
        }

        return array(
            'html' => '',
            'url' => wa()->getAppUrl('files').'?module=backend&action=profileTabFiles&id='.$contact_id,
            'count' => 0,
            'title' => _wd('files', 'Files').($total_count ? ' (' . $total_count . ')' : ''),
        );
    }
}

