<?php

class filesCopyCli extends waCliController
{
    public function execute()
    {
        $asm = new waAppSettingsModel();
        $asm->set('files', 'copy_cli_start', date('Y-m-d H:i:s'));
        $max_execution_time = (int) ini_get('max_execution_time');
        if ($max_execution_time <= 0) {
            $max_execution_time = 600;  // 10 min max
        }
        $copytask = new filesCopytask(5 * $this->getConfig()->getTasksPerRequest(), array(
            'max_execution_time' => $max_execution_time
        ));
        $copytask->execute();
        $asm->set('files', 'copy_cli_end', date('Y-m-d H:i:s'));
    }
}