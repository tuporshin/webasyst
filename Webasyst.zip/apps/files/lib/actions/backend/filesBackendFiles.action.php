<?php

class filesBackendFilesAction extends filesFilesAction
{}