<?php

class filesBackendChangesController extends filesController
{
    public function execute()
    {
        $hash = $this->getHash();
        $this->assign(array(
            'folder' => $this->getFileItemInfo(filesFileModel::TYPE_FOLDER, $hash),
            'file' => $this->getFileItemInfo(filesFileModel::TYPE_FILE, $hash),
            'storage' => $this->getStorageItemInfo($hash)
        ));
    }

    public function getFileItemInfo($type, $hash)
    {
        $info = null;

        $prefix = $type === filesFileModel::TYPE_FOLDER ? 'folder/' : 'file/';
        $len = strlen($prefix);
        if (substr($hash, 0, $len)) {
            $folder_id = (int) substr($hash, $len);
            if ($folder_id > 0) {
                $fm = $this->getFileModel();
                $res = $fm->select('id, update_datetime, count')->where('id = ? AND type = ?', $folder_id, $type)->fetchAll('id');
                if (!empty($res[$folder_id])) {
                    $info = $res[$folder_id];
                }
                if ($info && $type === 'folder') {
                    $res = $fm->select('COUNT(*) children_count, MAX(update_datetime) max_children_update_datetime')
                            ->where("parent_id = ?", $folder_id)->query()->fetchAssoc();
                    $info = array_merge($info, $res);
                }
            }
        }

        return $info;
    }

    public function getStorageItemInfo($hash)
    {
        $info = null;
        $prefix = 'storage/';
        $len = strlen($prefix);
        if (substr($hash, 0, $len)) {
            $storage_id = (int) substr($hash, $len);
            if ($storage_id > 0) {
                $sm = $this->getStorageModel();
                $res = $sm->select('id, count')->where('id = ?', $storage_id)->fetchAll('id');
                if (!empty($res[$storage_id])) {
                    $info = $res[$storage_id];
                }
                if ($info) {
                    $res = $this->getFileModel()->select('COUNT(*) children_count, MAX(update_datetime) max_children_update_datetime')
                        ->where("storage_id = ? AND parent_id = 0", $storage_id)->query()->fetchAssoc();
                    $info = array_merge($info, $res);
                }
            }
        }

        return $info;
    }

    public function getHash()
    {
        return trim((string) $this->getRequest()->request('hash'), '/');
    }
}

