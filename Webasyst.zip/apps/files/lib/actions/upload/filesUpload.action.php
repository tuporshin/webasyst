<?php

class filesUploadAction extends filesController
{
    public function execute()
    {
        $upload_max_file_size = $this->convertToBytes(ini_get('upload_max_filesize'));
        $post_max_size = $this->convertToBytes(ini_get('post_max_size'));
        $memory_limit = $this->convertToBytes(ini_get('memory_limit'));

        $max_file_size = floor(min($upload_max_file_size, 0.8 * $post_max_size, 0.7 * $memory_limit));

        $this->assign(array(
            'max_file_size' => $max_file_size
        ));
    }

    public function convertToBytes($val)
    {
        if(empty($val))return 0;

        $val = trim($val);

        preg_match('#([0-9]+)[\s]*([a-z]+)#i', $val, $matches);

        $last = '';
        if(isset($matches[2])){
            $last = $matches[2];
        }

        if(isset($matches[1])){
            $val = (int) $matches[1];
        }

        switch (strtolower($last))
        {
            case 'g':
            case 'gb':
                $val *= 1024;
            case 'm':
            case 'mb':
                $val *= 1024;
            case 'k':
            case 'kb':
                $val *= 1024;
        }

        return (int) $val;
    }
}