<?php

class filesStatisticsAction extends filesController
{
    public function execute()
    {

    }
}