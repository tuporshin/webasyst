<?php

class filesCopyTaskController extends filesController
{
    public function execute()
    {
        $copytask = new filesCopytask($this->getConfig()->getTasksPerRequest());
        $copytask->execute();
    }
}