<?php

class filesCopyProcessController extends filesCopytaskProcessController
{
}