<?php

class filesCopyFilesController extends filesController
{

    public function execute()
    {
        // get destination place and check it
        $folder_id = $this->getFolderId();
        $storage_id = $this->getStorageId();
        $error = $this->checkDestination($storage_id, $folder_id);
        if ($error) {
            $this->setError($error['msg']);
            return;
        }

        $file_ids = $this->getFiles();
        try {
            $res = $this->getFileModel()->copy($file_ids, $storage_id, $folder_id);
            $this->logAction('copy', join(',', $file_ids));
            $this->assign($res);
        } catch (filesException $e) {
            $this->errors = $e->getMessage();
        }
    }

    public function getFiles()
    {
        $file_ids = wa()->getRequest()->request('file_id', array(), waRequest::TYPE_ARRAY_INT);
        if (!$file_ids) {
            return array();
        }

        $hash = 'list/' . join(',', $file_ids);
        $collection = $this->getCollection($hash, array(
            'workup' => 'array_keys'
        ));
        return $collection->getItems('id', 0, count($file_ids));
    }

    public function getFolderId()
    {
        return wa()->getRequest()->post('folder_id', 0, waRequest::TYPE_INT);
    }

    public function getStorageId()
    {
        return wa()->getRequest()->post('storage_id', 0, waRequest::TYPE_INT);
    }

    public function checkDestination($storage_id, $folder_id)
    {
        if (!$storage_id && !$folder_id) {
            return $this->getPageNotFoundError();
        }
        if (!$folder_id) {
            if (!filesRights::inst()->canAddNewFilesIntoStorage($storage_id)) {
                return $this->getAccessDeniedError();
            }
            if ($this->getStorageModel()->inSync($storage_id)) {
                return $this->getInSyncError();
            }
        } else {
            if (!filesRights::inst()->canAddNewFilesIntoFolder($folder_id)) {
                return $this->getAccessDeniedError();
            }
            if ($this->getFileModel()->inSync($folder_id)) {
                return $this->getInSyncError();
            }
        }
        return null;
    }

}
