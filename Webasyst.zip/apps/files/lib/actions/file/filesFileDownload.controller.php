<?php

class filesFileDownloadController extends filesController
{
    public function execute()
    {
        $file = $this->getFile();
        if ($file['storage_id']) {
            $this->sendFile($file);
            return;
        } else {
            //TODO: hook
        }
    }

    public function sendFile($file)
    {
        wa()->getResponse()->addHeader('Expires', 'tomorrow');
        wa()->getResponse()->addHeader('Cache-Control', 'private, max-age=' . (86400*30));    // one month
        wa()->getResponse()->addHeader('Content-Type', 'application/octet-stream');

        $source = filesSource::factory($file['source_id']);
        $source->download($file);
        exit;
    }

    public function getFile()
    {
        $id = wa()->getRequest()->get('id', null, waRequest::TYPE_INT);
        $file = $this->getFileModel()->getFile($id);
        if (!$file) {
            $this->reportAboutError($this->getPageNotFoundError());
            return false;
        }
        if ($file['in_copy_process']) {
            $this->reportAboutError($this->getPageNotFoundError());
            return false;
        }
        $storage = $this->getStorageModel()->getStorage($file['storage_id']);
        if (!$storage) {
            $this->reportAboutError($this->getPageNotFoundError());
            return false;
        }
        if (!filesRights::inst()->canReadFile($file['id'])) {
            $this->reportAboutError($this->getAccessDeniedError());
            return false;
        }
        return $file;
    }

}