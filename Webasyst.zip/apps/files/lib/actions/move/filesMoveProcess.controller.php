<?php

class filesMoveProcessController extends filesCopytaskProcessController
{
}