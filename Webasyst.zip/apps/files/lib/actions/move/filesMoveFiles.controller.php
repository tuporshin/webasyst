<?php

class filesMoveFilesController extends filesController
{

    public function execute()
    {
        // get destination place and check it
        $folder_id = $this->getFolderId();
        $storage_id = $this->getStorageId();
        $error = $this->checkDestination($storage_id, $folder_id);
        if ($error) {
            $this->setError($error['msg']);
            return;
        }

        // get files and find out is there conflict
        $res = $this->getFiles();

        // unallowed to move files exist, terminate action and send response about it
        if ($res['unallowed_count'] > 0) {
            $this->assign(array(
                'unallowed_exist' => true
            ));
            return;
        }

        $files = $res['allowed'];

        if ($this->isCheckCountFirst()) {
            $max_move_folders = filesApp::inst()->getConfig()->getMaxMoveFolders();
            if ($this->getFileModel()->countChildrenWithParents($files) > $max_move_folders) {
                $this->errors = sprintf(_w('Maximum amount of folders for one copy process is %s.'), $max_move_folders);
            }
            // no conflicts - so just return
            return;
        }

        $conflict = $this->getFileModel()->getConflictFiles($files, $storage_id, $folder_id);

        // is there name conflict?
        if ($conflict) {

            // how to solve name conflict
            $solve = $this->getSolve();

            if (!in_array($solve, array('replace', 'exclude', 'rename'))) {
                $this->assign(array(
                    'files_conflict' => true,
                    'files' => $files
                ));
                return;
            } else if ($solve === 'replace') {
                $error = $this->solveByReplace($conflict);
                if ($error) {
                    $this->setError($error['msg']);
                    return;
                }
            } else if ($solve === 'exclude') {
                $files = $this->dropFilesByNames($files, $this->getExcludeNames($conflict));
            } else {
                // case rename is default solve behavior implemented in model method
                // so nothing to do
            }
        }

        // moving files and folders
        $res = $this->getFileModel()->moveItems(
            array_keys($files), $storage_id, $folder_id
        );

        $action_id = $this->isRestore() ? 'restore' : 'move';
        $this->logAction($action_id, join(',', array_keys($files)));

        $this->assign(array(
            'success' => $res ? true : false,
            'process_id' => is_array($res) && isset($res['process_id']) ? $res['process_id'] : null
        ));
    }

    public function getFiles()
    {
        $file_ids = wa()->getRequest()->request('file_id', null, waRequest::TYPE_ARRAY_INT);
        if (!$file_ids) {
            return array();
        }
        $files = $this->getFileModel()->getById($file_ids);
        if ($this->isRestore()) {
            $allowed = filesRights::inst()->dropHasNotAnyAccess($files);
        } else {
            $allowed = filesRights::inst()->dropUnallowedToMove($files);
        }

        $allowed = $this->dropInSync($allowed);

        return array(
            'allowed' => $allowed,
            'unallowed_count' => count($files) - count($allowed)
        );
    }

    public function dropInSync($files)
    {
        $sync_map = $this->getFileModel()->inSync($files);
        foreach ($files as $id => $file) {
            if (!empty($sync_map[$id])) {
                unset($files[$id]);
            }
        }
        return $files;
    }

    public function isRestore()
    {
        return wa()->getRequest()->request('restore');
    }

    public function solveByReplace($conflict)
    {
        if (!filesRights::inst()->canReplaceFiles($conflict['dst_conflict_files'])) {
            return $this->getAccessDeniedError();
        }
        $file_to_delete = array();
        foreach (array_keys($conflict['dst_conflict_files']) as $file_id) {
            if (isset($conflict['src_conflict_files'][$file_id])) {
                unset($conflict['src_conflict_files'][$file_id]);
            } else {
                $file_to_delete[] = $file_id;
            }
        }

        // check in_copy_process
        $in_copy_process = $this->getFileModel()->select('in_copy_process, id')->where('id IN (:ids)', array(
            'ids' => $file_to_delete
        ))->fetchAll('id', true);

        // drop in_copy_process files
        foreach ($file_to_delete as $index => $file_id) {
            if (!empty($in_copy_process[$file_id])) {
                unset($file_to_delete[$index]);
            }
        }

        // slice off locked files too
        $lm = new filesLockModel();
        $file_to_delete = $lm->sliceOffLocked($file_to_delete, filesLockModel::RESOURCE_TYPE_FILE, filesLockModel::SCOPE_EXCLUSIVE);

        if ($file_to_delete) {
            $this->getFileModel()->delete($file_to_delete);
        }
        if (!$conflict['src_conflict_files']) {
            return array('msg' => _w("Files from the same place"));
        }
        return null;
    }

    public function getExcludeNames($conflict)
    {
        return filesApp::getFieldValues($conflict['src_conflict_files'], 'name');
    }

    public function dropFilesByNames($files, $names)
    {
        foreach ($files as $file_id => $file) {
            if ($file['type'] === filesFileModel::TYPE_FILE && in_array($file['name'], $names)) {
                unset($files[$file_id]);
            }
        }
        return $files;
    }

    public function getSolve()
    {
        return wa()->getRequest()->post('solve', '', waRequest::TYPE_STRING_TRIM);
    }

    public function getFolderId()
    {
        return wa()->getRequest()->post('folder_id', 0, waRequest::TYPE_INT);
    }

    public function getStorageId()
    {
        return wa()->getRequest()->post('storage_id', 0, waRequest::TYPE_INT);
    }

    public function checkDestination($storage_id, $folder_id)
    {
        if (!$storage_id && !$folder_id) {
            return $this->getPageNotFoundError();
        }
        if (!$folder_id) {
            if (!filesRights::inst()->canAddNewFilesIntoStorage($storage_id)) {
                return $this->getAccessDeniedError();
            }
        } else {
            if (!filesRights::inst()->canAddNewFilesIntoFolder($folder_id)) {
                return $this->getAccessDeniedError();
            }
        }
        return null;
    }

    public function isCheckCountFirst()
    {
        return wa()->getRequest()->request('check_count_first');
    }

}
