<?php

class filesSourceSyncController extends filesController
{
    public function execute()
    {
        $res = self::runNextSyncTask();
        if ($res !== null && $res['result']['count'] > 0) {
            $this->assign(array(
                'source_id' => $res['source']->getId()
            ));
        }
    }

    public static function runNextSyncTask($options = array())
    {
        $sm = new filesSourceModel();

        $timeout = filesApp::inst()->getConfig()->getSyncTimeout();

        $source_info = $sm->getOneSynchronized($timeout);
        if (empty($source_info)) {
            return null;
        }

        $id = $source_info['id'];
        $source = filesSource::factory($id);
        if (empty($source)) {
            return null;
        }
        
        $sync = new filesSourceSync($source, $options);
        $data = $source->syncData();

        $list = ifset($data['list'], array());
        if (!empty($list)) {
            $sync->append($list);
        }

        $res = array('count' => 0);
        $is_done = ifset($data['info']['done'], false);
        if ($is_done) {
            $source->pauseSync();
            $res = $sync->process();
            $source->unpauseSync();
        }

        return array(
            'source' => $source,
            'result' => $res
        );
    }
}