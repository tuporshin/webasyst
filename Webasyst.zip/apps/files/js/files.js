( function($) {
    $.files = $.extend($.files || {}, {

        init: function(options) {

            // init app config
            this.config.init(options.config || {});

            // run background tasks
            this.runBackgroundTasks();

            // init sidebar
            new Sidebar($("#f-sidebar"));

            // init app controller
            $.files.controller.init();

            // global click on back list link
            if (history.back) {
                $('body').on('click', '.f-back-to-list', function() {
                    history.back();
                });
            }

            // kill wa-global ajax error handler for 403 errors
            $.wa.errorHandler = function(xhr) {
                if ($.files.getXWaFilesLocation(xhr)) {
                    $.wa.dialogHide();
                    return false;
                }
                if (xhr.status === 403) {
                    $.files.alert403Error(xhr.responseText);
                    return false;
                }
            };

            $(document).ajaxComplete(function (event, xhr) {
                if ($.files.getXWaFilesLocation(xhr)) {
                    window.location.href = $.files.getXWaFilesLocation(xhr);
                    $.wa.dialogHide();
                    return false;
                }
            });
            
        },

        load: function (url, callback, options) {
            options = options || {};
            var load_protector = $.files.load_protector = Math.random();
            var container = $.files.config.getMainContainer();
            if (options.container) {
                if ($.type(options.container) === 'string' && $(options.container).length) {
                    container = $(options.container);
                } else if (options.container.length) {
                    container = $(options.container);
                }
            }
            var loading = $('.f-loading', container).show();

            var render = function(result) {

                var $content = $('.f-load-block', container).first();

                loading.hide();

                if (load_protector !== $.files.load_protector) {
                    // too late!
                    return;
                }
                var tmp = $('<div></div>').html(result);
                var title = tmp.find('.h-main-title').text();
                if (title) {
                    $.files.setBrowserTitle(title);
                }
                tmp.remove();
                $content.html(result);

                if (callback) {
                    try {
                        callback.call(this);
                    } catch (e) {

                    }
                }

                $(window).trigger($.Event('wa_loaded'));

            };

            var onSuccess = $.files.load.onSuccess || render;
            var onError = $.files.load.onError || function(result) { render(result.responseText); }
            $.get(url)
                .success(function (r, s, x) {
                    if ($.files.getXWaFilesLocation(x)) {
                        return;
                    }
                    onSuccess && onSuccess(r);
                })
                .error(function (r, s, x) {
                    if ($.files.getXWaFilesLocation(r)) {
                        return;
                    }
                    onError && onError(r);
                })
                .always(function (r, s, x) {
                    if ($.files.getXWaFilesLocation(x)) {
                        return;
                    }
                });
        },

        alert403Error: function(html) {
            var dialog = $('#f-403-error-dialog');
            $('.f-dialogs-section .dialog').not(dialog).hide();
            dialog.filesDialog({
                onLoad: function(dialog) {
                    $(this).find('.f-content').html(html);
                }
            });
        },

        alertError: function(error_msg, log_msg) {
            $('#f-error-dialog').filesDialog({
                onLoad: function () {
                    $(this).find('.f-text').html(error_msg);
                }
            });
            if (log_msg) {
                this.logError(log_msg);
            }
        },

        getXWaFilesLocation: function (xhr) {
            return (xhr && xhr.getResponseHeader && xhr.getResponseHeader('X-Wa-Files-Location')) || '';
        },

        confirmDelete: function (confirm_msg, ok, cancel) {
            var dialog = this.confirm(confirm_msg, ok, cancel);
            dialog.find('.f-confirm-ok').removeClass('green').addClass('red');
            dialog.find('.f-confirm-ok').val($_('Delete'));
            return dialog;
        },

        confirm: function(confirm_msg, ok, cancel) {
            var dialog = $('#f-confirm-dialog');

            dialog.find('.f-confirm-ok').removeClass('red').addClass('green');
            dialog.find('.f-confirm-ok').val($_('Yes'));

            var confirm_title = '';
            if ($.isPlainObject(confirm_msg)) {
                confirm_title = confirm_msg.title || '';
                confirm_msg = confirm_msg.msg || '';
            }

            dialog.filesDialog({
                onLoad: function() {
                    var dialog = $(this);
                    dialog.find('.f-title').html(confirm_title);
                    dialog.find('.f-text').html(confirm_msg);

                    var title_height = dialog.find('.f-title').height();
                    var content_height = dialog.find('.f-text').height();
                    var buttons_height = dialog.find('.dialog-buttons').height();
                    var total_height = content_height + buttons_height + title_height;
                    var max_height = 300;
                    var min_height = 150;
                    var height = Math.min(Math.max(total_height, max_height), min_height);

                    dialog.filesDialog('height', height);

                    dialog.find('.f-confirm-ok').unbind('.files')
                        .bind('click.files', function() {
                            dialog.trigger('close');
                            ok && ok.apply($(this));
                        });
                    dialog.find('.f-confirm-cancel').unbind('.files')
                        .bind('click.files', function() {
                            cancel && cancel.apply($(this));
                        });
                }
            });
            return dialog
        },

        jsonPost: function f(url, data, onSuccess, onError, onAlways) {
            if (arguments.length === 1 && $.isPlainObject(url)) {
                var options = url;
                url = options.url || '';
                data = options.data || '';
                onSuccess = options.onSuccess;
                onError = options.onError || options.onFailure || options.onFail;
                onAlways = options.onAlways;
            }
            f.run = f.run || {};
            if (f.run[url]) {
                return f.run[url];
            }
            var xhr = $.post(url, data,
                function(r, s, x) {
                    if ($.files.getXWaFilesLocation(x)) {
                        return;
                    }
                    if (!r) {
                        onError && onError();
                    } else {
                        onSuccess && onSuccess(r);
                    }
                }, 'json')
                .error(function(r) {
                    if ($.files.getXWaFilesLocation(r)) {
                        return;
                    }
                    if (r.status == 403) {
                        return;
                    } else {
                        onError && onError(r);
                    }
                })
                .always(function(r, s, x) {
                    delete f.run[url];
                    if ($.files.getXWaFilesLocation(x)) {
                        return;
                    }
                    onAlways && onAlways(r);
                });
            f.run[url] = xhr;
            return f.run[url];
        },

        showValidateErrors: function(errors, form) {
            $.each(errors, function(i, er) {
                var el = form.find('[name="' + er.name + '"]').addClass('error');
                var parent = el.parent();
                parent.append('<em class="errormsg">' + er.msg + '</em>');
            });
        },

        onFormChange: function(form, handler) {
            var all_inputs = form.find(':input');

            all_inputs.on('change.files_form_change', function() {
                handler.apply(form, [this]);
            });

            all_inputs.filter('select').on('click.files_form_change', function() {
                handler.apply(form, [this]);
            });

            var delay = 250;
            var timer_id = null;
            all_inputs.filter('textarea,input[type=text]').on('keydown.files_form_change', function() {
                if (timer_id) {
                    clearTimeout(timer_id);
                    timer_id = null;
                }
                var self = this;
                timer_id = setTimeout(function() {
                    handler.apply(form, [self]);
                }, delay);
            });

        },

        offFormChange: function(form) {
            form.find(':input,:select').off('.file_form_change');
        },

        clearValidateErrors: function(form) {
            form.find('.errormsg').remove()
                .end().find('.error').removeClass('error');
        },

        initLazyLoad: function(options) {
            var count = options.count;
            var offset = count;
            var total_count = options.total_count;
            var url = options.url;
            var container = $(options.container);
            var auto = typeof options.auto === 'undefined' ? true : options.auto;
            var win = $(window);
            win.lazyLoad('stop'); // stop previous lazy-load implementation

            if (offset < total_count) {
                win.lazyLoad({
                    container: container,
                    state: auto ? 'wake' : 'stop',
                    load: function() {
                        win.lazyLoad('sleep');
                        $('.f-lazyloading-link').hide();
                        $('.f-lazyloading-progress').show();
                        $.get(url + '&lazy=1&offset=' + offset + '&total_count=' + total_count, function(data) {
                            var html = $('<div></div>').html(data);
                            var list = html.find('.f-catalog-item');
                            if (list.length) {
                                offset += list.length;
                                $('.f-catalog-wrapper', container).append(list);
                                if (offset >= total_count) {
                                    win.lazyLoad('stop');
                                    $('.f-lazyloading-progress').hide();
                                } else {
                                    win.lazyLoad('wake');
                                    $('.f-lazyloading-link').show();
                                    if (!auto) {
                                        $('.f-lazyloading-progress').hide();
                                    }
                                }
                            } else {
                                win.lazyLoad('stop');
                                $('.f-lazyloading-progress').hide();
                            }

                            $('.f-lazyloading-progress-string', container).
                                    replaceWith(
                                        $('.f-lazyloading-progress-string', html)
                                    );
                            $('.f-lazyloading-chunk', container).
                                    replaceWith(
                                        $('.f-lazyloading-chunk', html)
                                    );

                            html.remove();

                            options.onLoad && options.onLoad();
                            $.files.retina();

                        });
                    }
                });
                container.on('click', '.lazyloading-link', function() {
                    $(window).lazyLoad('force');
                    return false;
                });
            }
        },

        refreshSidebar: function f() {
            if (f.load) {
                return;
            }
            f.load = true;
            var sidebar = $.files.config.getSidebar();
            var li = sidebar.find('.selected');
            var selector = (li.attr('class') || '').split(/\s+/).join('.');
            var xhr = $.get('?module=backend&action=sidebar', function(html) {
                $('#f-sidebar').html(html);
            }).always(function() {
                f.load = false;
                li = selector ? sidebar.find(selector) : $();
                if (li.length) {
                    li.addClass('selected');
                } else {
                    $.files.config.getSidebar().trigger('notify', {
                        hash: $.files.controller.getCurrentHash()
                    });
                }
            });
            return xhr;
        },

        setBrowserTitle: function(title, ignore_default_suffix) {
            var suffix = !ignore_default_suffix ? (' — ' + this.config.getAccountName()) : '';
            document.title = title + suffix;
        },

        iButton: function(elem, options) {
            var ibutton_options = $.extend({
                labelOn: '',
                labelOff: '',
                className: 'mini'
            }, options || {});
            elem.iButton(ibutton_options);
            return elem;
        },

        moveFiles: function(options) {

            var file_ids = options.file_ids || [];
            var storage_id = options.storage_id || 0;
            var folder_id = options.folder_id || 0;
            var is_restore = options.is_restore || '';
            var onFailure = (options.onFailure || options.onError || options.onFail);
            var onAlways = options.onAlways;
            var onSuccess = options.onSuccess;
            var beforeMoveFiles = options.beforeMoveFiles;
            
            // source place is the same as destination place
            if (
                (storage_id && $.files.controller.getCurrentStorageId() === storage_id)
                    ||
                (folder_id && $.files.controller.getCurrentFolderId() === folder_id)
            )
            {
                onFailure && onFailure({
                    same_place: true
                });
                return false;
            }

            var moveFiles = function () {

                beforeMoveFiles && beforeMoveFiles();

                $.files.jsonPost({
                    url: '?module=move&action=files' + (is_restore ? '&restore=1' : ''),
                    data: { folder_id: folder_id, storage_id: storage_id, file_id: file_ids },
                    onSuccess: function(r) {
                        if (r.status === 'ok' && r.data.success) {
                            onSuccess && onSuccess(r);
                        } else if (r.data.unallowed_exist) {
                            var file_id_str = $.map(file_ids, function(v) {
                                return 'file_id[]=' + v;
                            }).join('&');
                            $.files.loadDialog('?module=move&' + file_id_str +
                                '&storage_id=' + storage_id + '&folder_id=' + folder_id);
                        } else if (r.data.files_conflict) {
                            var file_id_str = $.map(file_ids, function(v) {
                                return 'file_id[]=' + v;
                            }).join('&');
                            $.files.loadDialog('?module=move&action=nameConflict&' + file_id_str +
                                '&storage_id=' + storage_id + '&folder_id=' + folder_id + (is_restore ? '&restore=1' : ''));
                        } else {
                            $.files.alertError(r.errors[0][0]);
                        }
                    },
                    onFailure: function(r) {
                        $.files.alertError($_('Server error'), r);
                        onFailure && onFailure();
                    },
                    onAlways: function() {
                        onAlways && onAlways();
                    }
                });
            };

            if (!is_restore) {
                $.files.jsonPost({
                    url: '?module=move&action=files&check_count_first=1',
                    data: { folder_id: folder_id, storage_id: storage_id, file_id: file_ids },
                    onSuccess: function (r) {
                        if (r.status != 'ok' && typeof r.errors === 'string') {
                            $.wa.dialogHide();
                            $.files.alertError(r.errors);
                            return;
                        }
                        if (r.status == 'ok') {
                            moveFiles();
                        }
                    },
                    onFailure: function (r) {
                        $.files.alertError($_('Server error'), r);
                    }
                });
            } else {
                moveFiles();
            }

        },

        filterSettingsFormSubmit: function(form, options) {
            form.find('.loading').show();
            $.files.clearValidateErrors(form);

            options = options || {};
            var onSuccess = options.onSuccess;
            var error = function(r)  {
                $.files.alertError($_("Couldn't save filter"), r);
            };

            // make post request
            $.files.jsonPost({
                url: '?module=filter&action=save',
                data: form.serialize(),
                onSuccess: function(r) {
                    if (r.status !== 'ok') {
                        $.files.showValidateErrors(r.errors, form);
                    } else if (!r.data.filter) {
                        error(r.data);
                    } else {
                        $.files.controller.gotoFilterPage(r.data.filter.id);
                        $.files.refreshSidebar();
                        onSuccess && onSuccess();
                    }
                },
                onFailure: error,
                onAlways: function() {
                    form.find('.loading').hide();
                }
            });
        },

        storageSettingsFormSubmit: function(form, options) {
            if (form.data('loading')) {
                return false;
            }
            form.data('loading', 1);
            form.find('.loading').show();
            $.files.clearValidateErrors(form);

            options = options || {};
            var onSuccess = options.onSuccess;
            var onAlways = options.onAlways;

            var error = function(r)  {
                if (r.status !== 403) {
                    $.files.alertError($_("Couldn't create storage"), r);
                }
            };

            // make post request
            $.files.jsonPost({
                url: '?module=storage&action=save',
                data: form.serialize(),
                onSuccess: function(r) {
                    if (r.status !== 'ok') {
                        $.files.showValidateErrors(r.errors, form);
                    } else if (!r.data.storage) {
                        error(r.data);
                    } else {
                        if (options.reload !== false) {
                            $.files.controller.gotoStoragePage(r.data.storage.id);
                        }
                        $.files.refreshSidebar();
                        onSuccess && onSuccess();
                    }
                },
                onFailure: error,
                onAlways: function() {
                    form.data('loading', 0);
                    form.find('.loading').hide();
                    onAlways && onAlways();
                }
            });
        },

        showNotificationMessage: function(message, color) {
            var height = 20;
            var width = 200;
            var hideDown = function(block) {
                block.animate({
                    height: 0
                }, 500, function() {
                    $(this).remove();
                });
            };

            if ($('.f-notification-message').length) {
                hideDown($('.f-notification-message'));
            }

            var block = $('<div>').addClass('f-notification-message block double-padded')
                .css({
                    display: 'none',
                    position: 'fixed',
                    width: width,
                    bottom: 0,
                    right: 0,
                    height: 0,
                    backgroundColor: color || '#FEF49C',
                    border: '2px solid #DDD'
                });
            block.append('<p>' + message + '</p>');
            block.appendTo($('body'));
            block.show().animate({
                height: height
            }, 500);

            setTimeout(function() {
                hideDown(block);
            }, 1500);

        },

        loadDialog: function f(url, options) {
            f.load = f.load || {};
            f.cache = f.cache || {};
            if (f.load[url]) {
                return;
            }
            options = options || {};
            var onLoad = options.onLoad;
            if (options.cache && f.cache[url]) {
                var d = $('#' + f.cache[url]);
                if (d.length) {
                    d.trigger('open');
                    onLoad && onLoad(d);
                    return;
                }
            }
            f.load[url] = true;
            $.get(url, function(html) {
                f.load[url] = false;
                var d = $('<div>').html(html);
                if (options.cache) {
                    f.cache[url] = d.find('.dialog').attr('id');
                }
                $('.f-dialogs-section').append(d);
                onLoad && onLoad(d.find('.dialog'));
            }).error(function(r) {
                if (r.status === 403) {
                    $.files.alert403Error(r.responseText);
                }
            });
        },

        parseFileName: function(filename) {
            var ext = '';
            var pos = filename.lastIndexOf('.');
            if (pos > 0) {
                ext = filename.slice(pos + 1);
                filename = filename.slice(0, pos);
            }
            return { filename: filename, ext: ext };
        },

        retina: function() {
            $.Retina && $('#wa-app').find('img:not(.f-retina-off)').addClass('f-retina-off').retina();
        },

        loc: function(p1, p2) {
            var res = $_(p1, p2) || '';
            if (p2) {
                res = res.replace('%d', p1);
            }
            return res;
        },

        ucfirst: function(str) {
            str = str || '';
            if (!str) {
                return '';
            }
            return str.slice(0, 1).toUpperCase() + str.slice(1);
        },

        lcfirst: function(str) {
            str = str || '';
            if (!str) {
                return '';
            }
            return str.slice(0, 1).toLowerCase() + str.slice(1);
        },

        logError: function(er) {
            if (console) {
                if (console.error) {
                    console.error(er);
                } else {
                    console.log(er);
                }
            }
        },

        runCopyFiles: function () {

            if (!$.files.config.canRunCopyFiles()) {
                return;
            }

            var coef = Math.floor(Math.random() * 100) / 100;
            var settings = {
                id: ('' + Math.random()).slice(2),
                delay: 10000 + coef * 5000,
                timer: null,
                xhr: null
            };

            var process = function () {
                try {

                    settings.timer && clearTimeout(settings.timer);
                    settings.xhr && settings.xhr.abort();

                    var run = function () {
                        if (!$.files.config.canRunCopyFiles()) {
                            settings.timer && clearTimeout(settings.timer);
                            settings.xhr && settings.xhr.abort();
                            return;
                        }
                        console.log('copytask [' + settings.id + '] start');
                        settings.xhr = $.files.jsonPost('?module=copy&action=task&process_id=' + settings.id);
                        settings.xhr.always(function () {
                            settings.xhr = null;
                            settings.timer = setTimeout(run, settings.delay);
                            console.log('copytask [' + settings.id + '] end');
                        });
                        settings.xhr.error(function () {
                            return false;
                        });
                    };

                    run();
                    settings.timer = setTimeout(run, settings.delay);
                } catch (Error) {
                    console.error(['runCopyFiles fail', Error]);
                }
            };

            process();


        },

        checkBackendChanges: function () {
            return $.files.jsonPost('?module=backend&action=changes',  { hash: $.files.controller.getCurrentHash() })
                .done(function (r) {

                    if (r.status !== 'ok') {
                        return;
                    }

                    var reload = false;
                    var itemUpdate = function (type, data) {
                        data.id = parseInt(data.id, 10);
                        var getId = function () {
                            if (type === 'file') {
                                return $.files.controller.getCurrentFileId();
                            } else if (type === 'folder') {
                                return $.files.controller.getCurrentFolderId();
                            } else if (type === 'storage') {
                                return $.files.controller.getCurrentStorageId();
                            } else {
                                return -1;
                            }
                        };
                        var getTime = function (datetime) {
                            return new Date(datetime || '1970-01-01').getTime();
                        };
                        if (data.id == getId()) {
                            var cur_update_ts = getTime(data.update_datetime);
                            var prev_update_ts = getTime($.files.config.getItemInfo(type, data.id, 'update_datetime'));

                            if (cur_update_ts > prev_update_ts) {
                                reload = true;
                            }

                            if (!reload) {
                                var cur_count = data.count;
                                var prev_count = $.files.config.getItemInfo(type, data.id, 'count');
                                if (cur_count != prev_count) {
                                    reload = true;
                                }
                            }

                            if (!reload && type !== 'file') {
                                var cur_children_count = data.children_count;
                                var prev_children_count = $.files.config.getItemInfo(type, data.id, 'children_count');
                                if (cur_children_count != prev_children_count) {
                                    reload = true;
                                }
                            }
                            if (!reload && type !== 'file') {
                                var cur_max_children_update_datetime = data.max_children_update_datetime;
                                var prev_max_children_update_datetime = $.files.config.getItemInfo(type, data.id, 'max_children_update_datetime');
                                if (cur_max_children_update_datetime != prev_max_children_update_datetime) {
                                    reload = true;
                                }
                            }

                            $.files.config.setItemInfo(type, data.id, data);
                        }
                    };

                    // check changes for folder and file
                    var data = r.data || {};
                    !$.isEmptyObject(data.folder) && itemUpdate('folder', data.folder);
                    !$.isEmptyObject(data.file) && itemUpdate('file', data.file);
                    !$.isEmptyObject(data.storage) && itemUpdate('storage', data.storage);

                    // reload page if needed
                    reload && $.files.controller.reloadPage();
                })
                .error(function () {
                    return false;
                });
        },

        runBackendChanges: function () {
            try {
                var coef = Math.floor(Math.random() * 100) / 100;
                var delay = 30000 + coef * 5000;
                var method = this.runBackendChanges;
                if (method.timer) {
                    clearTimeout(method.timer);
                    method.xhr.abort();
                }
                method.delay = delay;
                var run = function () {
                    if (method.xhr) {
                        return;
                    }
                    method.xhr = $.files.checkBackendChanges()
                        .always(function () {
                            method.xhr = null;
                            method.timer = setTimeout(run, method.delay);
                        });
                };
                run();
            } catch (Error) {
                console.error(['runBackendChanges fail', Error]);
            }
        },

        runSyncWithSources: function () {
            if (this.config.getSourceCount() <= 0 && this.runSyncWithSources.work) {
                return;
            }

            if (!$.files.config.canRunSyncWithSources()) {
                return;
            }

            this.runSyncWithSources.work = true;
            try {
                var coef = Math.floor(Math.random() * 100) / 100;
                var delay = 10000 + coef * 5000;
                var method = this.runSyncWithSources;
                if (method.timer) {
                    clearTimeout(method.timer);
                    method.xhr && method.xhr.abort();
                }
                method.delay = delay;
                var run = function () {

                    var hash = location.hash;
                    hash = (hash || '' ).replace(/(^[^#]*#\/*|\/$)/g, '');
                    if (hash.indexOf('source/') >= 0) {
                        // not running sync on source page (prevent race condition when first data pulling)
                        method.xhr = null;
                        method.timer = setTimeout(run, method.delay);
                        return;
                    }

                    if (method.paused) {
                        return;
                    }
                    if (method.xhr) {
                        return;
                    }

                    if (!$.files.config.canRunSyncWithSources()) {
                        method.timer && clearTimeout(method.timer);
                        method.xhr && method.xhr.abort();
                        return;
                    }

                    method.xhr = $.files.jsonPost('?module=source&action=sync');
                    method.xhr
                        .done(function (r) {
                            if (r.status === 'ok') {
                                var source_id = $.files.config.getSourceId();
                                if (source_id > 0 && r.data.source_id == source_id) {
                                    $.files.controller.reloadPage();
                                }
                            }
                        })
                        .always(function () {
                            method.xhr = null;
                            method.timer = setTimeout(run, method.delay);
                        })
                        .error(function () {
                            return false;
                        });
                };

                run();

                method.pause = function () {
                    method.paused = true;
                };

                method.unpause = function () {
                    method.paused = false;
                };

            } catch (Error) {
                this.runSyncWithSources.work = false;
                console.error(['runSyncWithSources fail', Error]);
            }
        },

        runBackgroundTasks: function () {

            var tasks = [this.runCopyFiles, this.runSyncWithSources, this.runBackendChanges];
            var flatted = [];

            for (var i = 0; i < tasks.length; i += 1) {
                if ($.isArray(tasks[i])) {
                    var task = tasks[i][0];
                    var times = tasks[i][1];
                    for (var t = 0; t < times; t += 1) {
                        flatted.push(task);
                    }
                } else {
                    flatted.push(tasks[i]);
                }
            }

            tasks = flatted;
            tasks = tasks.sort(function () {
                return Math.random() - Math.random();
            });

            for (var i = 0; i < tasks.length; i += 1) {
                (function(task) {
                    var coef = Math.floor(Math.random() * 100) / 100;
                    var delay = coef * 500;
                    setTimeout(function () {
                        task.apply($.files);
                    }, delay);
                })(tasks[i]);
            }
        },

        deleteSource: function(id) {
            return $.files.jsonPost({
                url: '?module=source&action=delete',
                data: { id: id },
                onSuccess: function(r) {
                    if (r.status === 'ok') {
                        $.files.refreshSidebar();
                        $.files.controller.gotoDefaultPage();
                    }
                }
            });
        }

    });
})(jQuery);
